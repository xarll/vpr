package main.controllers;

import main.models.Item;
import main.models.MainModel;
import main.views.main.MainView;

import java.util.ArrayList;

public class MainController {
    private final MainModel model;
    public final MainView view;



    public MainController(MainModel model) {
        this.model = model;
        this.view = new MainView(this);

        this.model.addObserver(this.view);

        this.view.loaded();
    }

    public void updateList() {
        this.model.updateList();
    }

    public void addItem(String filename, int size) {
        this.model.addItem(filename, size);
    }

    public void deleteItem(String id) {
        this.model.deleteItem(id);
    }

    public ArrayList<Item> getItems() {
        return this.model.getItems();
    }
}
