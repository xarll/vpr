package main.models;

import javafx.beans.property.*;
import javafx.beans.value.ObservableValue;

import java.util.Date;

public class Item {
    public StringProperty id;
    public StringProperty filename;
    public IntegerProperty size;
    public Property<Date> created_at;

    public Item(String id, String filename, Integer size, Date created_at) {
        this.id = new SimpleStringProperty(id);
        this.filename = new SimpleStringProperty(filename);
        this.size = new SimpleIntegerProperty(size);
        this.created_at = new SimpleObjectProperty<>(created_at);
    }

    public StringProperty filenameProperty() {
        return filename;
    }

    public IntegerProperty sizeProperty() {
        return size;
    }

    public Property<Date> created_atProperty() {
        return created_at;
    }
}
