package main.views.main;

import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.util.converter.IntegerStringConverter;
import main.models.Item;

import java.util.Date;


public class UiMain {

    private final VBox root;
    Button addButton;
    TableView<Item> tableView;

    UiMain(VBox root) {
        this.root = root;
    }

    void setup_ui() {
        root.setAlignment(Pos.CENTER_RIGHT);

        // TableView
        tableView = new TableView<>();
        tableView.setTableMenuButtonVisible(true);
        VBox.setVgrow(tableView, Priority.ALWAYS);
        root.getChildren().add(tableView);

        TableColumn<Item, String> filenameCol = new TableColumn<>("Имя файла");
        filenameCol.setMinWidth(100);
        filenameCol.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");
        filenameCol.setCellValueFactory(cellData -> cellData.getValue().filenameProperty());
        filenameCol.setCellFactory(TextFieldTableCell.forTableColumn());

        TableColumn<Item, Integer> filesizeCol = new TableColumn<>("Размер");
        filesizeCol.setMinWidth(100);
        filesizeCol.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");
        filesizeCol.setCellValueFactory(cellData -> cellData.getValue().sizeProperty().asObject());
        filesizeCol.setCellFactory(TextFieldTableCell.forTableColumn(new IntegerStringConverter()));

        TableColumn<Item, Date> created_atCol = new TableColumn<>("Дата создания");
        created_atCol.setMinWidth(100);
        created_atCol.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");
        created_atCol.setCellValueFactory(cellData -> cellData.getValue().created_atProperty());
        created_atCol.setCellFactory(TextFieldTableCell.forTableColumn(new javafx.util.converter.DateStringConverter()));


        tableView.getColumns().addAll(filenameCol, filesizeCol, created_atCol);

        // Tools

        addButton = new Button("Добавить");
        addButton.setPrefWidth(100);
        VBox.setMargin(addButton, new javafx.geometry.Insets(10, 10, 10, 10));

        root.getChildren().add(addButton);
    }
}


