package main.views.main;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;
import javafx.geometry.Insets;
import javafx.scene.layout.GridPane;

import main.controllers.MainController;
import main.views.BaseView;

import java.util.Optional;


public class MainView extends BaseView {
    private final UiMain ui;
    private final MainController controller;

    public MainView(MainController controller) {
        var root = new VBox();
        scene = new Scene(root, 800, 600);

        this.controller = controller;

        this.ui = new UiMain(root);
        this.ui.setup_ui();

        // Регистрация событий
        this.ui.addButton.setOnMouseClicked(this::addClicked);
        this.ui.tableView.setOnMouseClicked(this::itemDoubleClicked);
    }


    public void modelChanged() {

        ui.tableView.setItems(FXCollections.observableArrayList(controller.getItems()));
    }

    public void loaded() {
        controller.updateList();
    }


    private void itemDoubleClicked(MouseEvent mouseEvent) {

        if (mouseEvent.getClickCount() != 2) {
            return;
        }


        // Control Window
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 20, 20, 20));


        var item = ui.tableView.getSelectionModel().getSelectedItem();

        var filename = ui.tableView.getSelectionModel().getSelectedItem().filenameProperty().get();
        var size = ui.tableView.getSelectionModel().getSelectedItem().sizeProperty().get();
        var created_at = ui.tableView.getSelectionModel().getSelectedItem().created_atProperty().getValue();

        grid.add(new Label("Имя: "), 0, 0);
        grid.add(new TextField(filename), 1, 0);
        grid.add(new Label("Размер: "), 0, 1);
        grid.add(new TextField(String.valueOf(size)), 1, 1);
        grid.add(new Label("Дата создания: "), 0, 2);
        grid.add(new TextField(String.valueOf(created_at)), 1, 2);

        ButtonType okButton = new ButtonType("OK", ButtonBar.ButtonData.OK_DONE);
        ButtonType deleteButton = new ButtonType("Удалить", ButtonBar.ButtonData.OTHER);

        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle("Управление записью");
        dialog.getDialogPane().setContent(grid);
        dialog.getDialogPane().getButtonTypes().addAll(okButton, deleteButton);

        Optional<ButtonType> result = dialog.showAndWait();

        result.ifPresent(buttonType -> {
            if (buttonType == deleteButton) {
                controller.deleteItem(item.id.get());
            }
        });
    }


    private void addClicked(MouseEvent mouseEvent) {
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 20, 20, 20));


        var filename = new TextField();
        var size = new TextField();
        size.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                size.setText(newValue.replaceAll("[^\\d]", ""));
            }
        });
        grid.add(new Label("Имя: "), 0, 0);
        grid.add(filename, 1, 0);
        grid.add(new Label("Размер: "), 0, 1);
        grid.add(size, 1, 1);

        ButtonType okButton = new ButtonType("OK", ButtonBar.ButtonData.OK_DONE);
        ButtonType cancelButton = new ButtonType("Отмена", ButtonBar.ButtonData.CANCEL_CLOSE);

        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle("Ввод данных");
        dialog.getDialogPane().setContent(grid);
        dialog.getDialogPane().getButtonTypes().addAll(okButton, cancelButton);

        Optional<ButtonType> result = dialog.showAndWait();

        result.ifPresent(buttonType -> {
            var isInputNotEmpty = !filename.getText().isEmpty() && !size.getText().isEmpty();
            if (buttonType == okButton && isInputNotEmpty) {
                controller.addItem(filename.getText(), Integer.parseInt(size.getText()));
            }
        });
    }
}
