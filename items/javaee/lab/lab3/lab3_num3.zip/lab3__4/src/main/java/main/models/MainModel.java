package main.models;


import main.utils.DObserver;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;

public class MainModel {

    private final ArrayList<Object> observers;

    private final ArrayList<Item> items;


    public MainModel() {
        this.observers = new ArrayList<>();
        this.items = new ArrayList<>();
    }

    public void deleteItem(String id) {
        try {
            // Хз где тут найти встроенный url Builder
            final URL url = new URL("http://localhost:8080/api/gallery?id=" + id);

            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("DELETE");
            connection.setRequestProperty("User-Agent", "Mozilla/5.0");
            connection.setConnectTimeout(1000);

            int status = connection.getResponseCode();
            System.out.println(status);
            if (status != 200) {
                return;
            }
            updateList();
        } catch (IOException errorObj) {
            return;
        }
    }


    public void addItem(String filename, Integer size) {
        try {
            // Хз где тут найти встроенный url Builder
            final URL url = new URL("http://localhost:8080/api/gallery?filename=" + filename + "&size=" + size);

            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("User-Agent", "Mozilla/5.0");
            connection.setConnectTimeout(1000);

            int status = connection.getResponseCode();

            if (status != 200) {
                return;
            }
            updateList();
        } catch (IOException errorObj) {
            return;
        }
    }

    public void updateList() {
        try {
            // Хз где тут найти встроенный url Builder
            final URL url = new URL("http://localhost:8080/api/gallery");

            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setRequestProperty("User-Agent", "Mozilla/5.0");
            connection.setConnectTimeout(1000);

            int status = connection.getResponseCode();

            if (status != 200) {
                return;
            }

            InputStream inputStream = connection.getInputStream();

            // Читаем ответ
            byte[] buffer = new byte[1024];
            int bytesRead;
            StringBuilder responseContent = new StringBuilder();
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                responseContent.append(new String(buffer, 0, bytesRead));
            }
            inputStream.close();

            JSONObject json = new JSONObject(responseContent.toString());
            JSONArray jsonArray = json.getJSONArray("data");
            // Json трансляторы в obj в jAVA просто уродливые, придется делать вручную
            this.items.clear();
            for (int i = 0; i < jsonArray.length(); i++) {
                this.items.add(
                    new Item(
                            jsonArray.getJSONObject(i).getString("id"),
                            jsonArray.getJSONObject(i).getString("filename"),
                            jsonArray.getJSONObject(i).getInt("size"),
                            new Date(jsonArray.getJSONObject(i).getLong("created_at"))
                    )
                );
                System.out.println();
            }

        } catch (IOException errorObj) {
            return;
        }
        notifyObservers();
    }

    public void addObserver(DObserver observer) {
        this.observers.add(observer);
    }

    public void notifyObservers() {
        for (Object observer : this.observers) {
            ((DObserver) observer).modelChanged();
        }
    }

    public void removeObserver(DObserver observer) {
        this.observers.remove(observer);
    }

    public ArrayList<Item> getItems() {
        return this.items;
    }
}
