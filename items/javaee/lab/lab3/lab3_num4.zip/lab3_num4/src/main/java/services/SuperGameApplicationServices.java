package services;

import models.APIException;
import models.Coordinate;
import models.schemas.GameData;
import views.ASResponse;

import javax.servlet.http.HttpSession;
import java.util.ArrayList;

public class SuperGameApplicationServices {


    public static ASResponse<GameData, APIException> startGame(HttpSession session) {
        ArrayList<ArrayList<Boolean>> map = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            ArrayList<Boolean> row = new ArrayList<>();
            for (int j = 0; j < 3; j++) {
                row.add(null);
            }
            map.add(row);
        }
        GameData gameData = new GameData(map);
        session.setAttribute("gameData", gameData);
        return new ASResponse<>(gameData, null);
    }

    public static ASResponse<GameData, APIException> putStep(Integer x, Integer y, HttpSession session) {
        if (x == null || y == null) {
            return new ASResponse<>(null, new APIException("Координаты не могут быть пустыми ", 400));
        }
        GameData gameData = (GameData) session.getAttribute("gameData");
        if (gameData == null) {
            return new ASResponse<>(null, new APIException("Игра не начата ", 400));
        }
        if (gameData.winner != null) {
            return new ASResponse<>(null, new APIException("Игра окончена ", 400));
        }
        if (x < 0 || x > 2 || y < 0 || y > 2) {
            return new ASResponse<>(null, new APIException("Координаты должны быть в диапазоне от 0 до 2 ", 400));
        }
        if (gameData.map.get(y).get(x) != null) {
            return new ASResponse<>(null, new APIException("Клетка занята ", 400));
        }
        // User step
        gameData.map.get(y).set(x, true);

        // Computer step
        ArrayList<Coordinate> freeCoordinates = new ArrayList<>();
        for (int i = 0; i < gameData.map.size(); i++) {
            for (int j = 0; j < gameData.map.get(i).size(); j++) {
                if (gameData.map.get(i).get(j) == null) {
                    freeCoordinates.add(new Coordinate(j, i));
                }
            }
        }

        if (!freeCoordinates.isEmpty()) {
            Coordinate computerStep = freeCoordinates.get((int) (Math.random() * freeCoordinates.size()));
            gameData.map.get(computerStep.y).set(computerStep.x, false);
        }


        int result = getWinner(gameData.map);
        if (result == 0 && freeCoordinates.isEmpty()) {
            gameData.winner = result;
            session.removeAttribute("gameData");
            return new ASResponse<>(gameData, null);
        }
        if (result != 0) {
            gameData.winner = result;
            session.removeAttribute("gameData");
            return new ASResponse<>(gameData, null);
        }

        session.setAttribute("gameData", gameData);
        return new ASResponse<>(gameData, null);
    }


    private static int getWinner(ArrayList<ArrayList<Boolean>> map) {
        // Winner in rows
        int winner = getRowWinner(map);
        if (winner != 0) {
            return winner;
        }

        // Expanded matrix
        ArrayList<ArrayList<Boolean>> expandedMap = new ArrayList<>();
        for (int i = 0; i < map.size(); i++) {
            ArrayList<Boolean> row = new ArrayList<>();
            for (int j = 0; j < map.get(i).size(); j++) {
                row.add(map.get(j).get(i));
            }
            expandedMap.add(row);
        }
        // Check columns
        winner = getRowWinner(expandedMap);
        if (winner != 0) {
            return winner;
        }

        // Check diagonal Main
        winner = getDiagonalWinner(map, true);
        if (winner != 0) {
            return winner;
        }

        // Check diagonal Not Main
        winner = getDiagonalWinner(map, false);

        return winner;
    }

    private static int getRowWinner(ArrayList<ArrayList<Boolean>> map) {
        int winner = 0;
        for (ArrayList<Boolean> booleanArrayList : map) {
            boolean isUserWin = true;
            boolean isComputerWin = true;
            for (Boolean item : booleanArrayList) {
                if (item == null) {
                    isUserWin = false;
                    isComputerWin = false;
                    break;
                }
                if (item) {
                    isComputerWin = false;
                }
                if (!item) {
                    isUserWin = false;
                }
            }
            if (isUserWin) {
                winner = 1;
                break;
            }
            if (isComputerWin) {
                winner = 2;
                break;
            }
        }
        return winner;
    }

    private static int getDiagonalWinner(ArrayList<ArrayList<Boolean>> map, boolean isMain) {
        boolean isUserWin = true;
        boolean isComputerWin = true;
        for (int i = 0; i < map.size(); i++) {
            Boolean item = map.get(i).get(isMain ? i : map.size() - i - 1);
            if (item == null) {
                isUserWin = false;
                isComputerWin = false;
                break;
            }
            if (item) {
                isComputerWin = false;
            }
            if (!item) {
                isUserWin = false;
            }
        }

        if (isUserWin) {
            return 1;
        }

        if (isComputerWin) {
            return 2;
        }
        return 0;

    }
}
