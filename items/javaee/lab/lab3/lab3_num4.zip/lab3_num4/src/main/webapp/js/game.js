
async function makeStep() {
  const x = document.getElementById("x");
  const y = document.getElementById("y");

  const url = new URL(`${location.origin}/api/game`);
  url.searchParams.set("x", x.value);
  url.searchParams.set("y", y.value);

  const response = await fetch(url, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json;charset=utf-8"
      },
  });

  let data = await response.json();
  console.log(data);

  if (response.ok) {
    drawMap(data.data.map);

    if (data.data.winner !== null) {
      let textWin = "Результат: "
      if (data.data.winner === 1) {
        textWin += "победил Пользователь";
      } else if (data.data.winner === 2) {
        textWin += "победил Компьютер";
      } else {
        textWin += "Ничья";
      }
      setErrorMessage(textWin);
      document.getElementById("makeStepField").innerHTML = "";
    }

  } else {
    setErrorMessage("Error: " + response.status + " " + data.exception.message);
  }

}


async function restartGame(id) {
  console.log(id);

  const url = new URL(`${location.origin}/api/gallery`);
  url.searchParams.set("id", id);

  const response = await fetch(url, {
    method: "DELETE",
    headers: {
      "Content-Type": "application/json;charset=utf-8"
    },
  });

  if (response.ok) {
    await load(document.getElementById("sort").value);
  }
}

function drawMap(map) {
  const rows = document.getElementById("rows");

  rows.innerHTML = map.map((row) => {
    return `
      <tr>
        <td>y${map.indexOf(row)}</td>
        <td>${row[0] == null ? " ": row[0] ? "X" : "O"}</td>
        <td>${row[1] == null ? " ": row[1] ? "X" : "O"}</td>
        <td>${row[2] == null ? " ": row[2] ? "X" : "O"}</td>
      </tr>
    `;
  }).join("");

}

function setErrorMessage(message) {
    const errorBox = document.getElementById("errorBox");
    errorBox.innerHTML = message;
}

async function startGame() {
  const url = new URL(`${location.origin}/api/game`);
  const response = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json;charset=utf-8"
    },
  });

  const data = await response.json();
  console.log(data);
  drawMap(data.data.map);
}



document.addEventListener("DOMContentLoaded", async () => {
  await startGame();
  document.getElementById("addItemButton").addEventListener("click", makeStep);

});
