package models.schemas;

import java.util.ArrayList;

public class GameData {
    public ArrayList<ArrayList<Boolean>> map;

    public Integer winner;


    public GameData(ArrayList<ArrayList<Boolean>> map) {
        this.map = map;
        this.winner = null;
    }

}
