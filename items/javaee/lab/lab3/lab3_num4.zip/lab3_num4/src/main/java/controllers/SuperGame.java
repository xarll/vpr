package controllers;

import com.fasterxml.jackson.databind.ObjectMapper;
import models.APIException;
import models.schemas.GameData;
import services.SuperGameApplicationServices;
import views.ASResponse;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "SuperGame", value = "/api/game")
public class SuperGame extends HttpServlet {

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        // Pre-process
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        HttpSession session = request.getSession();

        // Process
        ASResponse<GameData, APIException> resp = SuperGameApplicationServices.startGame(session);

        // Post-Process
        if (resp.exception != null) {
            response.setStatus(resp.exception.code);
        }
        ObjectMapper objectMapper = new ObjectMapper();
        String jsonString = objectMapper.writeValueAsString(resp);
        PrintWriter out = response.getWriter();
        out.print(jsonString);
        out.flush();
        out.close();
    }

    public void doPut(HttpServletRequest request, HttpServletResponse response) throws IOException {
        // Pre-process
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        HttpSession session = request.getSession();

        // Process
        ASResponse<GameData, APIException> resp = SuperGameApplicationServices.putStep(
                Integer.parseInt(request.getParameter("x")),
                Integer.parseInt(request.getParameter("y")),
                session
        );

        // Post-Process
        if (resp.exception != null) {
            response.setStatus(resp.exception.code);
        }
        ObjectMapper objectMapper = new ObjectMapper();
        String jsonString = objectMapper.writeValueAsString(resp);
        PrintWriter out = response.getWriter();
        out.print(jsonString);
        out.flush();
        out.close();
    }
}