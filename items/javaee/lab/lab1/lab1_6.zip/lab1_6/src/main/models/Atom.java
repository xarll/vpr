package main.models;

public class Atom {
    public double x;
    public double y;
    public double z;
    public String title;
    public String color;
    public int radius;

    public Atom(double x, double y, double z, String title, String color, int radius) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.title = title;
        this.color = color;
        this.radius = radius;
    }

    public void rotate(Double angleX, Double angleY) {
        double cosX = Math.cos(Math.toRadians(angleX));
        double sinX = Math.sin(Math.toRadians(angleX));
        double cosY = Math.cos(Math.toRadians(angleY));
        double sinY = Math.sin(Math.toRadians(angleY));

        double x = this.x;
        double y = this.y;
        double z = this.z;

        // Поворачиваем вокруг оси X
        double newY = cosX * y - sinX * z;
        double newZ = sinX * y + cosX * z;

        // Поворачиваем вокруг оси Y
        this.x = cosY * x + sinY * newZ;
        this.y = newY;
        this.z = -sinY * x + cosY * newZ;
    }
}
