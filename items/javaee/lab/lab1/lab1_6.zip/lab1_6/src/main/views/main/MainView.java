package main.views.main;

import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.geometry.Point3D;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.image.WritableImage;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.paint.PhongMaterial;
import javafx.scene.shape.Cylinder;
import javafx.scene.shape.Sphere;
import javafx.scene.transform.Rotate;
import javafx.scene.transform.Translate;
import javafx.stage.FileChooser;
import main.controllers.MainController;
import main.models.Atom;
import main.views.BaseView;

import java.awt.image.BufferedImage;
import java.io.File;


public class MainView extends BaseView {
    private final UiMain ui;
    private final MainController controller;

    private double anchorX, anchorY;
    private double angleX = 0;
    private double angleY = 0;

    Atom selectedAtom;


    public MainView(MainController controller) {
        var root = new VBox();
        scene = new Scene(root, 900, 600);

        this.controller = controller;

        this.ui = new UiMain(root);
        this.ui.setup_ui();

        // Регистрация событий
        this.ui.openMenuItem.setOnAction(this::openFileClicked);
        this.ui.saveMenuItem.setOnAction(this::saveFileClicked);
        this.ui.saveImageMenuItem.setOnAction(this::saveImageClicked);
        this.ui.exitMenuItem.setOnAction(controller::exit);
        this.ui.scene3D.setOnMouseDragged(this::scene3DDragged);
        this.ui.scene3D.setOnMousePressed(this::scene3DPressed);

        this.ui.atom_x_input.setOnAction(this::atomCoordinateChanged);
        this.ui.atom_y_input.setOnAction(this::atomCoordinateChanged);
        this.ui.atom_z_input.setOnAction(this::atomCoordinateChanged);
        this.ui.atom_color_input.setOnAction(this::atomColorChanged);
        this.ui.atom_radius_input.setOnAction(this::atomRadiusChanged);
    }

    public void modelChanged() {
        // Очищаем сцену
        ui.scene3D.setRoot(new javafx.scene.Group());

        // Добавляем атомы
        for (Atom atom : controller.getAtoms()) {
            Sphere sphere = new Sphere(atom.radius);
            sphere.setTranslateX(atom.x);
            sphere.setTranslateY(atom.y);
            sphere.setTranslateZ(atom.z);
            sphere.setMaterial(new PhongMaterial(Color.valueOf(atom.color)));

            sphere.setOnMouseClicked(event -> {
                selectedAtom = atom;
                ui.atom_title.setText(atom.title);
                ui.atom_x_input.setText(String.valueOf(atom.x));
                ui.atom_y_input.setText(String.valueOf(atom.y));
                ui.atom_z_input.setText(String.valueOf(atom.z));
                ui.atom_color_input.setValue(Color.valueOf(atom.color));
                ui.atom_radius_input.setText(String.valueOf(atom.radius));
            });

            ((Group) ui.scene3D.getRoot()).getChildren().add(sphere);
        }

        // Связи
        for (int i = 0; i < controller.getAtoms().size(); i++) {
            for (int j = 0; j < controller.getAtoms().size(); j++) {
                if (i == j) continue;

                Atom atom1 = controller.getAtoms().get(i);
                Atom atom2 = controller.getAtoms().get(j);
                Cylinder cylinder = createCylinder(
                        new Point3D(atom1.x, atom1.y, atom1.z),
                        new Point3D(atom2.x, atom2.y, atom2.z)
                );
                cylinder.setMaterial(new PhongMaterial(Color.BLACK));
                ((Group) ui.scene3D.getRoot()).getChildren().add(cylinder);
            }
        }

        if (selectedAtom != null) {
            ui.atom_title.setText(selectedAtom.title);
            ui.atom_x_input.setText(String.valueOf(selectedAtom.x));
            ui.atom_y_input.setText(String.valueOf(selectedAtom.y));
            ui.atom_z_input.setText(String.valueOf(selectedAtom.z));
            ui.atom_color_input.setValue(Color.valueOf(selectedAtom.color));
        }
        ui.description.setText(controller.getDescription());
    }

    public void loaded() {
        modelChanged();
    }

    private void saveImageClicked(ActionEvent actionEvent) {
        FileChooser fc = new FileChooser();
        fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("Image files", "*.png"));
        File file = fc.showSaveDialog(null);

        if (file != null) {
            WritableImage writableImage = new WritableImage(
                    (int) ui.scene3D.getWidth(),
                    (int) ui.scene3D.getHeight()
            );
            ui.scene3D.snapshot(null, writableImage);
            BufferedImage bufferedImage = SwingFXUtils.fromFXImage(writableImage, null);
            controller.saveImage(bufferedImage, file);
        }
    }


    private void openFileClicked(ActionEvent actionEvent) {
        FileChooser fc = new FileChooser();
        fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("Text files", "*.txt"));
        File file = fc.showOpenDialog(null);


        if (file != null) {
            controller.openFile(file);
        }
    }

    private void saveFileClicked(ActionEvent actionEvent) {
        FileChooser fc = new FileChooser();
        fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("Text files", "*.txt"));
        File file = fc.showSaveDialog(null);

        if (file != null) {
            controller.saveFile(file);
        }
    }

    private void atomColorChanged(ActionEvent actionEvent) {
        if (selectedAtom == null) return;

        controller.setAtomColor(
                controller.getAtoms().indexOf(selectedAtom),
                ui.atom_color_input.getValue().toString()
        );
    }

    private void scene3DPressed(MouseEvent event) {
        anchorX = event.getSceneX();
        anchorY = event.getSceneY();
    }

    private void shiftAxis(double shiftX, double shiftY) {
        for (Atom atom : controller.getAtoms()) {
            atom.x += shiftX;
            atom.y += shiftY;
        }
        modelChanged();
    }

    private void scene3DDragged(MouseEvent event) {
        double deltaX = (event.getSceneX() - anchorX) / 150000;
        double deltaY = (event.getSceneY() - anchorY) / 150000;

        angleX += deltaY;
        angleY += deltaX;

        if (angleX > 90) angleX = 90;
        if (angleX < -90) angleX = -90;

        shiftAxis(-200, -200);

        for (Atom atom : controller.getAtoms()) {
            atom.rotate(angleX, angleY);
        }

        shiftAxis(200, 200);

        modelChanged();
    }

    private void atomCoordinateChanged(ActionEvent actionEvent) {
        if (selectedAtom == null) return;

        controller.setAtomCoordinates(
            controller.getAtoms().indexOf(selectedAtom),
            Double.parseDouble(ui.atom_x_input.getText()),
            Double.parseDouble(ui.atom_y_input.getText()),
            Double.parseDouble(ui.atom_z_input.getText())
        );

    }

    private void atomRadiusChanged(ActionEvent actionEvent) {
        if (selectedAtom == null) return;

        controller.setAtomRadius(
                controller.getAtoms().indexOf(selectedAtom),
                Integer.parseInt(ui.atom_radius_input.getText())
        );
    }

    public Cylinder createCylinder(Point3D origin, Point3D target) {
        Point3D yAxis = new Point3D(0, 1, 0);
        Point3D diff = target.subtract(origin);

        double height = diff.magnitude();
        Point3D mid = target.midpoint(origin);
        var moveToMidpoint = new Translate(mid.getX(), mid.getY(), mid.getZ());
        Point3D axisOfRotation = diff.crossProduct(yAxis);

        double angle = Math.acos(diff.normalize().dotProduct(yAxis));
        Rotate rotateAroundCenter = new Rotate(-Math.toDegrees(angle), axisOfRotation);
        Cylinder line = new Cylinder(1, height);
        line.getTransforms().addAll(moveToMidpoint, rotateAroundCenter);
        return line;
    }

}