package main.views.main;

import javafx.animation.TranslateTransition;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.PerspectiveCamera;
import javafx.scene.SceneAntialiasing;
import javafx.scene.SubScene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.chart.LineChart;
import javafx.scene.control.*;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.paint.Color;
import javafx.scene.paint.PhongMaterial;
import javafx.scene.shape.Sphere;
import javafx.scene.transform.Translate;
import javafx.util.Duration;
import javafx.util.converter.IntegerStringConverter;

import java.security.cert.PolicyNode;


public class UiMain {

    private final VBox root;

    SubScene scene3D;

    TextField atom_x_input;
    TextField atom_y_input;
    TextField atom_z_input;

    ColorPicker atom_color_input;

    TextField atom_radius_input;

    Label atom_title;

    Label description;

    MenuItem openMenuItem;
    MenuItem saveMenuItem;
    MenuItem saveImageMenuItem;
    MenuItem exitMenuItem;

    UiMain(VBox root) {
        this.root = root;
    }

    void setup_ui() {

        // Menubar
        var menuBar = new javafx.scene.control.MenuBar();
        var fileMenu = new javafx.scene.control.Menu("Файл");
        fileMenu.setStyle("-fx-font-size: 15px;");

        openMenuItem = new MenuItem("Открыть");
        openMenuItem.setStyle("-fx-font-size: 15px;");

        saveMenuItem = new MenuItem("Сохранить");
        saveMenuItem.setStyle("-fx-font-size: 15px;");

        saveImageMenuItem = new MenuItem("Сохранить как img");
        saveImageMenuItem.setStyle("-fx-font-size: 15px;");

        exitMenuItem = new MenuItem("Выход");
        exitMenuItem.setStyle("-fx-font-size: 15px;");

        fileMenu.getItems().addAll(openMenuItem, saveMenuItem, saveImageMenuItem, exitMenuItem);
        menuBar.getMenus().addAll(fileMenu);
        root.getChildren().add(menuBar);

        var central_layout = new HBox();
        root.getChildren().add(central_layout);


        // 3D Scene
        scene3D = new SubScene(new Group(), 600, root.getHeight(), true, SceneAntialiasing.BALANCED);
        scene3D.setFill(Color.PINK);
        central_layout.getChildren().add(scene3D);


        Group group = new Group();
        scene3D.setRoot(group);


        // Control panel
        var control_panel = new VBox();
        control_panel.setSpacing(10);
        control_panel.setPadding(new javafx.geometry.Insets(10, 10, 10, 10));
        control_panel.setAlignment(Pos.TOP_CENTER);
        central_layout.getChildren().add(control_panel);


        // Info panel
        var info_panel = new VBox();
        info_panel.setSpacing(10);
        info_panel.setPadding(new javafx.geometry.Insets(10, 10, 10, 10));
        info_panel.setAlignment(Pos.TOP_CENTER);
        control_panel.getChildren().add(info_panel);

        // Info panel: atom title
        var atom_title_layout = new HBox();
        atom_title_layout.setSpacing(10);
        atom_title_layout.setPadding(new javafx.geometry.Insets(10, 10, 10, 10));
        atom_title_layout.setAlignment(Pos.CENTER_RIGHT);
        info_panel.getChildren().add(atom_title_layout);

        var atom_title_label = new Label("Atom: ");
        atom_title_label.setFont(new javafx.scene.text.Font(15));
        atom_title_layout.getChildren().add(atom_title_label);

        atom_title = new Label();
        atom_title.setFont(new javafx.scene.text.Font(20));
        atom_title_layout.getChildren().add(atom_title);

        // Info panel: description
        var description_layout = new HBox();
        description_layout.setSpacing(10);
        description_layout.setPadding(new javafx.geometry.Insets(10, 10, 10, 10));
        description_layout.setAlignment(Pos.CENTER_RIGHT);
        info_panel.getChildren().add(description_layout);

        var description_label = new Label("Описание: ");
        description_label.setFont(new javafx.scene.text.Font(15));
        description_layout.getChildren().add(description_label);

        description = new Label();
        description.setFont(new javafx.scene.text.Font(20));
        description_layout.getChildren().add(description);

        // Control panel: atom
        var atom_layout = new VBox();
        atom_layout.setSpacing(10);
        atom_layout.setPadding(new javafx.geometry.Insets(10, 10, 10, 10));
        atom_layout.setAlignment(Pos.TOP_CENTER);
        control_panel.getChildren().add(atom_layout);

        // Control panel: atom: x
        var atom_x = new HBox();
        atom_x.setSpacing(10);
        atom_x.setPadding(new javafx.geometry.Insets(10, 10, 10, 10));
        atom_x.setAlignment(Pos.CENTER_RIGHT);
        atom_layout.getChildren().add(atom_x);

        // Control panel: atom: x: label
        var atom_x_label = new Label("X:");
        atom_x_label.setFont(new javafx.scene.text.Font(20));
        atom_x.getChildren().add(atom_x_label);

        // Control panel: atom: x: input
        atom_x_input = new TextField();
        atom_x_input.setPrefWidth(100);
        atom_x_input.setFont(new javafx.scene.text.Font(20));
        atom_x.getChildren().add(atom_x_input);

        // Control panel: atom: y
        var atom_y = new HBox();
        atom_y.setSpacing(10);
        atom_y.setPadding(new javafx.geometry.Insets(10, 10, 10, 10));
        atom_y.setAlignment(Pos.CENTER_RIGHT);
        atom_layout.getChildren().add(atom_y);

        // Control panel: atom: y: label
        var atom_y_label = new Label("Y:");
        atom_y_label.setFont(new javafx.scene.text.Font(20));
        atom_y.getChildren().add(atom_y_label);

        // Control panel: atom: y: input
        atom_y_input = new TextField();
        atom_y_input.setPrefWidth(100);
        atom_y_input.setFont(new javafx.scene.text.Font(20));
        atom_y.getChildren().add(atom_y_input);

        // Control panel: atom: z
        var atom_z = new HBox();
        atom_z.setSpacing(10);
        atom_z.setPadding(new javafx.geometry.Insets(10, 10, 10, 10));
        atom_z.setAlignment(Pos.CENTER_RIGHT);
        atom_layout.getChildren().add(atom_z);

        // Control panel: atom: z: label
        var atom_z_label = new Label("Z:");
        atom_z_label.setFont(new javafx.scene.text.Font(20));
        atom_z.getChildren().add(atom_z_label);

        // Control panel: atom: z: input
        atom_z_input = new TextField();
        atom_z_input.setPrefWidth(100);
        atom_z_input.setFont(new javafx.scene.text.Font(20));
        atom_z.getChildren().add(atom_z_input);

        // Control panel: atom: Color
        var atom_color = new HBox();
        atom_color.setSpacing(10);
        atom_color.setPadding(new javafx.geometry.Insets(10, 10, 10, 10));
        atom_color.setAlignment(Pos.CENTER_RIGHT);
        atom_layout.getChildren().add(atom_color);

        // Control panel: atom: Color: label
        var atom_color_label = new Label("Цвет:");
        atom_color_label.setFont(new javafx.scene.text.Font(20));
        atom_color.getChildren().add(atom_color_label);

        // Control panel: atom: Color: input
        atom_color_input = new ColorPicker();
        atom_color_input.setPrefWidth(100);
        atom_color.getChildren().add(atom_color_input);


        // Control panel: atom: Radius

        var atom_radius = new HBox();
        atom_radius.setSpacing(10);
        atom_radius.setPadding(new javafx.geometry.Insets(10, 10, 10, 10));
        atom_radius.setAlignment(Pos.CENTER_RIGHT);
        atom_layout.getChildren().add(atom_radius);

        var atom_radius_label = new Label("Размер: ");
        atom_radius_label.setFont(new javafx.scene.text.Font(20));
        atom_radius.getChildren().add(atom_radius_label);

        atom_radius_input = new TextField();
        atom_radius_input.setPrefWidth(100);
        atom_radius_input.setFont(new javafx.scene.text.Font(20));
        atom_radius.getChildren().add(atom_radius_input);
    }
}


