package main.models;


import main.utils.DObserver;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;
import java.util.Scanner;
import java.util.function.UnaryOperator;

public class MainModel {

    private final ArrayList<Object> observers;

    private String description;

    private ArrayList<Atom> atoms;


    public MainModel() {
        this.observers = new ArrayList<>();
        this.atoms = new ArrayList<>();
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
        notifyObservers();
    }

    public ArrayList<Atom> getAtoms() {
        return atoms;
    }

    public void setAtomColor(int index, String color) {
        this.atoms.get(index).color = color;
        notifyObservers();
    }

    public void setAtomRadius(int index, int radius) {
        this.atoms.get(index).radius = radius;
        notifyObservers();
    }

    public void setAtomCoordinates(int index, double x, double y, double z) {
        this.atoms.get(index).x = x;
        this.atoms.get(index).y = y;
        this.atoms.get(index).z = z;
        notifyObservers();
    }

    public void loadFromFile(String filePath) {
        try {
            FileInputStream fin = new FileInputStream(filePath);
            Scanner sc = new Scanner(fin);

            int count = Integer.parseInt(sc.nextLine());
            description = sc.nextLine();

            HashMap<String, String> colorMap = new HashMap<>();
            HashMap<String, Integer> radiusMap = new HashMap<>();
            int counter = 0;
            while (sc.hasNextLine()) {
                String line = sc.nextLine();
                if (line.isEmpty()) {
                    break;
                }

                String[] items = line.split(" ");

                if (colorMap.get(items[0]) == null) {
                    var random = new Random();
                    int red = random.nextInt(256);
                    int green = random.nextInt(256);
                    int blue = random.nextInt(256);

                    colorMap.put(items[0], String.format("#%02X%02X%02X", red, green, blue));
                }

                if (radiusMap.get(items[0]) == null) {
                    Random random = new Random();
                    radiusMap.put(items[0], random.nextInt(10) + 5);
                }

                atoms.add(new Atom(
                    Double.parseDouble(items[1]),
                    Double.parseDouble(items[2]),
                    Double.parseDouble(items[3]),
                    items[0],
                    colorMap.get(items[0]),
                    radiusMap.get(items[0])
                ));
                counter++;
            }
            fin.close();
            if (counter != count) {
                throw new IOException("Wrong file data");
            }
            notifyObservers();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void saveToFile(String filePath) {
        try {
            FileOutputStream fout = new FileOutputStream(filePath);
            PrintWriter pw = new PrintWriter(fout);

            pw.println(atoms.size());
            pw.println(description);

            for (Atom atom : atoms) {
                pw.println(atom.title + " " + atom.x + " " + atom.y + " " + atom.z);
            }

            pw.close();
            fout.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void saveImage(BufferedImage bufferedImage, String filePath) {
        try {
            ImageIO.write(bufferedImage, "png", new File(filePath));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void addObserver(DObserver observer) {
        this.observers.add(observer);
    }

    public void notifyObservers() {
        for (Object observer : this.observers) {
            ((DObserver) observer).modelChanged();
        }
    }

    public void removeObserver(DObserver observer) {
        this.observers.remove(observer);
    }
}
