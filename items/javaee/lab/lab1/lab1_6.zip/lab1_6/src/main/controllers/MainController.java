package main.controllers;

import javafx.event.ActionEvent;
import main.models.Atom;
import main.models.MainModel;
import main.views.main.MainView;

import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;

public class MainController {
    private final MainModel model;
    public final MainView view;



    public MainController(MainModel model) {
        this.model = model;
        this.view = new MainView(this);

        this.model.addObserver(this.view);

        this.view.loaded();
    }

    public void openFile(File file) {
        this.model.loadFromFile(String.valueOf(file));
    }

    public void saveFile(File file) {
        this.model.saveToFile(String.valueOf(file));

    }

    public void exit(ActionEvent actionEvent) {
        System.exit(0);
    }

    public ArrayList<Atom> getAtoms() {
        return this.model.getAtoms();
    }

    public void setAtomCoordinates(int index, double x, double y, double z) {
        this.model.setAtomCoordinates(index, x, y, z);
    }

    public String getDescription() {
        return model.getDescription();
    }

    public void setAtomColor(int index, String color) {
        model.setAtomColor(index, color);
    }

    public void setAtomRadius(int index, int radius) {
        model.setAtomRadius(index, radius);
    }

    public void saveImage(BufferedImage bufferedImage, File file) {
        model.saveImage(bufferedImage, String.valueOf(file));
    }
}
