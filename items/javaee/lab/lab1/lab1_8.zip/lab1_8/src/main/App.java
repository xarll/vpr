package main;

import javafx.animation.*;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.util.Duration;

public class App extends Application {

    @Override
    public void start(Stage primaryStage) {
        Rectangle rect = new Rectangle(100, 100, Color.BLUE);

        Button fadeInButton = new Button("Fade In");
        Button fadeOutButton = new Button("Fade Out");
        Button moveButton = new Button("Move");
        Button rotateButton = new Button("Rotate");
        Button scaleButton = new Button("Scale");

        // События
        fadeInButton.setOnAction(e -> fadeInAnimation(rect));
        fadeOutButton.setOnAction(e -> fadeOutAnimation(rect));
        moveButton.setOnAction(e -> moveAnimation(rect));
        rotateButton.setOnAction(e -> rotateAnimation(rect));
        scaleButton.setOnAction(e -> scaleAnimation(rect));


        var buttonBox = new HBox(10, fadeInButton, fadeOutButton, moveButton, rotateButton, scaleButton);
        buttonBox.setAlignment(Pos.CENTER);

        VBox root = new VBox(20, rect, buttonBox);
        root.setAlignment(Pos.CENTER);

        Scene scene = new Scene(root, 400, 400);
        primaryStage.setScene(scene);
        primaryStage.setTitle("SupaTest");
        primaryStage.show();
    }

    private void fadeInAnimation(Rectangle rect) {
        FadeTransition fadeTransition = new FadeTransition(Duration.seconds(2), rect);
        fadeTransition.setFromValue(0);
        fadeTransition.setToValue(1);
        fadeTransition.play();
    }

    private void fadeOutAnimation(Rectangle rect) {
        FadeTransition fadeTransition = new FadeTransition(Duration.seconds(2), rect);
        fadeTransition.setFromValue(1);
        fadeTransition.setToValue(0);
        fadeTransition.play();
    }

    private void moveAnimation(Rectangle rect) {
        TranslateTransition translateTransition = new TranslateTransition(Duration.seconds(2), rect);
        double oldX = rect.getTranslateX();
        translateTransition.setByX(50);
        translateTransition.play();
        translateTransition.setOnFinished(e -> rect.setTranslateX(oldX));
    }

    private void rotateAnimation(Rectangle rect) {
        RotateTransition rotateTransition = new RotateTransition(Duration.seconds(2), rect);
        rotateTransition.setByAngle(360);
        rotateTransition.play();
    }

    private void scaleAnimation(Rectangle rect) {
        ScaleTransition scaleIn = new ScaleTransition(Duration.seconds(1), rect);
        scaleIn.setToX(2);
        scaleIn.setToY(2);

        ScaleTransition scaleOut = new ScaleTransition(Duration.seconds(1), rect);
        scaleOut.setToX(1);
        scaleOut.setToY(1);

        SequentialTransition sequentialTransition = new SequentialTransition(scaleIn, scaleOut);
        sequentialTransition.play();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
