package main.views.main;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;
import javafx.geometry.Insets;
import javafx.scene.layout.GridPane;

import main.controllers.MainController;
import main.views.BaseView;

import java.util.Optional;


public class MainView extends BaseView {
    private final UiMain ui;
    private final MainController controller;

    private ObservableList<ProgramLanguage> data;

    public MainView(MainController controller) {
        var root = new VBox();
        scene = new Scene(root, 800, 600);

        this.controller = controller;

        this.ui = new UiMain(root);
        this.ui.setup_ui();

        // Регистрация событий
        this.ui.addButton.setOnMouseClicked(this::addClicked);
        this.ui.tableView.setOnMouseClicked(this::itemDoubleClicked);
    }


    public void modelChanged() {
    }

    public void loaded() {
        data = FXCollections.observableArrayList(
            new ProgramLanguage("Си", "Деннис Ритчи", 1972),
            new ProgramLanguage("C++", "Бьерн Страуструп", 1983),
            new ProgramLanguage("Python", "Гвидо ван Россум", 1991),
            new ProgramLanguage("Java", "Джеймс Гослинг", 1995),
            new ProgramLanguage("JavaScript", "Брендон Айк", 1995),
            new ProgramLanguage("C#", "Андерс Хейлсберг", 2001),
            new ProgramLanguage("Scala", "Мартин Одерски", 2003)
        );
        ui.tableView.setItems(data);

        modelChanged();

    }


    private void itemDoubleClicked(MouseEvent mouseEvent) {

        if (mouseEvent.getClickCount() != 2) {
            return;
        }


        // Control Window
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 20, 20, 20));


        var item = ui.tableView.getSelectionModel().getSelectedItem();

        var oldLang = ui.tableView.getSelectionModel().getSelectedItem().getLanguage();
        var oldAuthor = ui.tableView.getSelectionModel().getSelectedItem().getAuthor();
        var oldYear = Integer.toString(ui.tableView.getSelectionModel().getSelectedItem().getYear());


        var lang = new TextField(
            ui.tableView.getSelectionModel().getSelectedItem().getLanguage()
        );
        lang.textProperty().addListener((observable, oldValue, newValue) -> {
            item.setLanguage(newValue);
        });

        var author = new TextField(
            ui.tableView.getSelectionModel().getSelectedItem().getAuthor()
        );
        author.textProperty().addListener((observable, oldValue, newValue) -> {
            item.setAuthor(newValue);
        });
        var year = new TextField(
            Integer.toString(ui.tableView.getSelectionModel().getSelectedItem().getYear())
        );
        year.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                year.setText(newValue.replaceAll("[^\\d]", ""));
            } else
                item.setYear(Integer.parseInt(newValue.replaceAll("[^\\d]", "")));

        });
        grid.add(new Label("Язык: "), 0, 0);
        grid.add(lang, 1, 0);
        grid.add(new Label("Автор: "), 0, 1);
        grid.add(author, 1, 1);
        grid.add(new Label("Год: "), 0, 2);
        grid.add(year, 1, 2);

        ButtonType okButton = new ButtonType("OK", ButtonBar.ButtonData.OK_DONE);
        ButtonType deleteButton = new ButtonType("Удалить", ButtonBar.ButtonData.OTHER);

        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle("Управление записью");
        dialog.getDialogPane().setContent(grid);
        dialog.getDialogPane().getButtonTypes().addAll(okButton, deleteButton);

        Optional<ButtonType> result = dialog.showAndWait();

        result.ifPresent(buttonType -> {
            var isInputNotEmpty = !lang.getText().isEmpty() && !author.getText().isEmpty() && !year.getText().isEmpty();
            if (!isInputNotEmpty) {
                item.setLanguage(oldLang);
                item.setAuthor(oldAuthor);
                item.setYear(Integer.parseInt(oldYear));
            }
            if (buttonType == deleteButton) {
                data.remove(item);
            }
        });

    }


    private void addClicked(MouseEvent mouseEvent) {
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 20, 20, 20));


        var lang = new TextField();
        var author = new TextField();
        var year = new TextField();
        year.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                year.setText(newValue.replaceAll("[^\\d]", ""));
            }
        });
        grid.add(new Label("Язык: "), 0, 0);
        grid.add(lang, 1, 0);
        grid.add(new Label("Автор: "), 0, 1);
        grid.add(author, 1, 1);
        grid.add(new Label("Год: "), 0, 2);
        grid.add(year, 1, 2);

        ButtonType okButton = new ButtonType("OK", ButtonBar.ButtonData.OK_DONE);
        ButtonType cancelButton = new ButtonType("Отмена", ButtonBar.ButtonData.CANCEL_CLOSE);

        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle("Ввод данных");
        dialog.getDialogPane().setContent(grid);
        dialog.getDialogPane().getButtonTypes().addAll(okButton, cancelButton);

        Optional<ButtonType> result = dialog.showAndWait();

        result.ifPresent(buttonType -> {
            var isInputNotEmpty = !lang.getText().isEmpty() && !author.getText().isEmpty() && !year.getText().isEmpty();
            if (buttonType == okButton && isInputNotEmpty) {
                data.add(new ProgramLanguage(lang.getText(), author.getText(), Integer.parseInt(year.getText())));
            }
        });
    }
}
