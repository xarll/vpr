package main.controllers;

import main.models.MainModel;
import main.views.main.MainView;

public class MainController {
    private final MainModel model;
    public final MainView view;



    public MainController(MainModel model) {
        this.model = model;
        this.view = new MainView(this);

        this.model.addObserver(this.view);

        this.view.loaded();
    }
}
