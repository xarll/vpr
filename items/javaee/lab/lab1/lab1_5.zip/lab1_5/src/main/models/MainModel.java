package main.models;


import main.utils.DObserver;

import java.util.ArrayList;
import java.util.function.UnaryOperator;

public class MainModel {

    private final ArrayList<Object> observers;


    public MainModel() {
        this.observers = new ArrayList<>();
    }


    public void addObserver(DObserver observer) {
        this.observers.add(observer);
    }

    public void notifyObservers() {
        for (Object observer : this.observers) {
            ((DObserver) observer).modelChanged();
        }
    }

    public void removeObserver(DObserver observer) {
        this.observers.remove(observer);
    }

}
