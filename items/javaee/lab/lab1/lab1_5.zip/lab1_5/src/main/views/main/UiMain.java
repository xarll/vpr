package main.views.main;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.chart.LineChart;
import javafx.scene.control.*;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.paint.Color;
import javafx.util.converter.IntegerStringConverter;

import java.security.cert.PolicyNode;


public class UiMain {

    private final VBox root;
    Button addButton;
    TableView<ProgramLanguage> tableView;

    UiMain(VBox root) {
        this.root = root;
    }

    void setup_ui() {
        root.setAlignment(Pos.CENTER_RIGHT);

        // TableView
        tableView = new TableView<>();
        tableView.setTableMenuButtonVisible(true);
        VBox.setVgrow(tableView, Priority.ALWAYS);
        root.getChildren().add(tableView);

        TableColumn<ProgramLanguage, String> languageCol = new TableColumn<>("Язык");
        languageCol.setMinWidth(100);
        languageCol.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");
        languageCol.setCellValueFactory(cellData -> cellData.getValue().languageProperty());
        languageCol.setCellFactory(TextFieldTableCell.forTableColumn());

        TableColumn<ProgramLanguage, String> authorCol = new TableColumn<>("Автор");
        authorCol.setMinWidth(200);
        authorCol.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");
        authorCol.setCellValueFactory(cellData -> cellData.getValue().authorProperty());
        authorCol.setCellFactory(TextFieldTableCell.forTableColumn());

        TableColumn<ProgramLanguage, Integer> yearCol = new TableColumn<>("Год");
        yearCol.setMinWidth(100);
        yearCol.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");
        yearCol.setCellValueFactory(cellData -> cellData.getValue().yearProperty().asObject());
        yearCol.setCellFactory(TextFieldTableCell.forTableColumn(new IntegerStringConverter()));

        languageCol.setOnEditCommit(event -> {
            ProgramLanguage item = event.getRowValue();
            item.setLanguage(event.getNewValue());
        });

        authorCol.setOnEditCommit(event -> {
            ProgramLanguage item = event.getRowValue();
            item.setAuthor(event.getNewValue());
        });

        tableView.getColumns().addAll(languageCol, authorCol, yearCol);

        // Tools

        addButton = new Button("Добавить");
        addButton.setPrefWidth(100);
        VBox.setMargin(addButton, new javafx.geometry.Insets(10, 10, 10, 10));

        root.getChildren().add(addButton);
    }
}


