package main.models;

public enum PrimitiveType {
    LINE,
    CIRCLE,
    RECTANGLE,
    ELLIPSE
}
