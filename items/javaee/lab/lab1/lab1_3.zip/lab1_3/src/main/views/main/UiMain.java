package main.views.main;

import javafx.geometry.Pos;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.paint.Color;


public class UiMain {

    private final VBox root;
    Canvas canvas;
    ToggleGroup buttonGroup;
    VBox toggleButtonLayout;

    ColorPicker strokeColor;
    ColorPicker fillColor;
    TextField borderSize;
    ChoiceBox<String> borderType;

    TextField width;
    TextField height;

    MenuItem saveMenuItem;
    MenuItem exitMenuItem;
    MenuItem instructionMenuItem;


    UiMain(VBox root) { this.root = root; }

    void setup_ui() {
        // Menubar
        var menuBar = new javafx.scene.control.MenuBar();
        var fileMenu = new javafx.scene.control.Menu("Файл");
        var helpMenu = new javafx.scene.control.Menu("Помощь");

        saveMenuItem = new MenuItem("Сохранить");
        exitMenuItem = new MenuItem("Выход");
        instructionMenuItem = new MenuItem("Инструкция");

        fileMenu.getItems().addAll(saveMenuItem, exitMenuItem);
        helpMenu.getItems().addAll(instructionMenuItem);
        menuBar.getMenus().addAll(fileMenu, helpMenu);
        root.getChildren().add(menuBar);

        var central_layout = new HBox();
        central_layout.setAlignment(Pos.CENTER);
        central_layout.setSpacing(10);
        root.getChildren().add(central_layout);


        // Панель для отображения изображений
        canvas = new Canvas();
        GraphicsContext gc = canvas.getGraphicsContext2D();
        gc.setFill(Color.WHITE);

        Pane graphicPane = new Pane(canvas);
        graphicPane.setMinWidth(400);
        graphicPane.setMinHeight(600);
        canvas.widthProperty().bind(graphicPane.widthProperty());
        canvas.heightProperty().bind(graphicPane.heightProperty());
        HBox.setHgrow(canvas, Priority.ALWAYS);
        HBox.setHgrow(graphicPane, Priority.ALWAYS);
        gc.fillRect(0, 0, canvas.getWidth(), canvas.getHeight());
        central_layout.getChildren().add(graphicPane);

        // Управление
        var control_layout = new VBox();
        control_layout.setAlignment(Pos.CENTER);
        control_layout.setMinWidth(320);
        control_layout.setSpacing(100);
        central_layout.getChildren().add(control_layout);


        // Инструменты
        var tools_layout = new HBox();
        tools_layout.setAlignment(Pos.CENTER);
        tools_layout.setSpacing(10);
        control_layout.getChildren().add(tools_layout);

        // -- Кнопки примитивов
        this.buttonGroup = new ToggleGroup();
        buttonGroup.selectedToggleProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue == null) {oldValue.setSelected(true);}
        });
        this.toggleButtonLayout = new VBox();
        this.toggleButtonLayout.setAlignment(Pos.CENTER);
        VBox.setMargin(this.toggleButtonLayout, new javafx.geometry.Insets(10, 10, 10, 10));
        tools_layout.getChildren().add(toggleButtonLayout);

        // -- Инструменты заливок
        var fill_layout = new VBox();
        fill_layout.setAlignment(Pos.CENTER);
        VBox.setMargin(fill_layout, new javafx.geometry.Insets(10, 10, 10, 10));
        tools_layout.getChildren().add(fill_layout);

        // ---- Цвет контура
        var strokeColorLabel = new javafx.scene.control.Label("Цвет контура");
        strokeColorLabel.setFont(new javafx.scene.text.Font(16));
        strokeColorLabel.setAlignment(Pos.CENTER);
        fill_layout.getChildren().add(strokeColorLabel);

        strokeColor = new ColorPicker(Color.BLACK);
        strokeColor.setMinHeight(40);
        strokeColor.setMaxWidth(Double.MAX_VALUE);
        VBox.setMargin(strokeColor, new javafx.geometry.Insets(10, 10, 10, 10));
        fill_layout.getChildren().add(strokeColor);


        // ---- Цвет заливки
        var fillColorLabel = new javafx.scene.control.Label("Цвет заливки");
        fillColorLabel.setFont(new javafx.scene.text.Font(16));
        fillColorLabel.setAlignment(Pos.CENTER);
        fill_layout.getChildren().add(fillColorLabel);

        fillColor = new ColorPicker(Color.WHITE);
        fillColor.setMaxWidth(Double.MAX_VALUE);
        fillColor.setMinHeight(40);
        VBox.setMargin(fillColor, new javafx.geometry.Insets(10, 10, 10, 10));
        fill_layout.getChildren().add(fillColor);

        // ---- Толщина контура
        var borderSizeLabel = new javafx.scene.control.Label("Толщина контура");
        borderSizeLabel.setFont(new javafx.scene.text.Font(16));
        borderSizeLabel.setAlignment(Pos.CENTER);
        fill_layout.getChildren().add(borderSizeLabel);

        borderSize = new javafx.scene.control.TextField();
        borderSize.setMaxWidth(Double.MAX_VALUE);
        VBox.setMargin(borderSize, new javafx.geometry.Insets(10, 10, 10, 10));
        borderSize.setMinHeight(40);
        borderSize.setText("1");
        borderSize.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                borderSize.setText(newValue.replaceAll("[^\\d]", ""));
            }
        });
        fill_layout.getChildren().add(borderSize);

        // ---- Тип контура
        var borderTypeLabel = new javafx.scene.control.Label("Тип контура");
        borderTypeLabel.setFont(new javafx.scene.text.Font(16));
        borderTypeLabel.setAlignment(Pos.CENTER);
        fill_layout.getChildren().add(borderTypeLabel);

        borderType = new javafx.scene.control.ChoiceBox<String>();
        borderType.setMinHeight(40);
        borderType.setMaxWidth(Double.MAX_VALUE);
        VBox.setMargin(borderType, new javafx.geometry.Insets(10, 10, 10, 10));
        fill_layout.getChildren().add(borderType);

        // -- Инструменты размеров
        var size_layout = new VBox();
        size_layout.setAlignment(Pos.CENTER);
        VBox.setMargin(size_layout, new javafx.geometry.Insets(10, 10, 10, 10));
        control_layout.getChildren().add(size_layout);

        // ---- Ширина
        var widthLayout = new HBox();
        widthLayout.setAlignment(Pos.CENTER);
        VBox.setMargin(widthLayout, new javafx.geometry.Insets(10, 10, 10, 10));
        size_layout.getChildren().add(widthLayout);

        var widthLabel = new javafx.scene.control.Label("Ширина: ");
        widthLabel.setFont(new javafx.scene.text.Font(16));
        widthLabel.setAlignment(Pos.CENTER);
        widthLayout.getChildren().add(widthLabel);

        width = new javafx.scene.control.TextField();
        width.setMaxWidth(Double.MAX_VALUE);
        HBox.setHgrow(width, Priority.ALWAYS);
        VBox.setMargin(width, new javafx.geometry.Insets(10, 10, 10, 10));
        width.setText("100");
        width.setMinHeight(40);
        width.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                width.setText(newValue.replaceAll("[^\\d]", ""));
            }
        });
        widthLayout.getChildren().add(width);


        // ---- Высота
        var heightLayout = new HBox();
        heightLayout.setAlignment(Pos.CENTER);
        VBox.setMargin(heightLayout, new javafx.geometry.Insets(10, 10, 10, 10));
        size_layout.getChildren().add(heightLayout);

        var heightLabel = new javafx.scene.control.Label("Высота: ");
        heightLabel.setFont(new javafx.scene.text.Font(16));
        heightLabel.setAlignment(Pos.CENTER);
        heightLayout.getChildren().add(heightLabel);

        height = new javafx.scene.control.TextField();
        height.setMaxWidth(Double.MAX_VALUE);
        HBox.setHgrow(height, Priority.ALWAYS);
        VBox.setMargin(height, new javafx.geometry.Insets(10, 10, 10, 10));
        height.setText("100");
        height.setMinHeight(40);
        height.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                height.setText(newValue.replaceAll("[^\\d]", ""));
            }
        });
        heightLayout.getChildren().add(height);

    }
}
