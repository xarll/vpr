package main.views.main;

import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ToggleButton;
import javafx.scene.image.WritableImage;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.StrokeLineCap;
import javafx.stage.FileChooser;
import main.controllers.MainController;
import main.models.BorderType;
import main.models.PrimitiveType;
import main.views.BaseView;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


public class MainView extends BaseView {
    private final UiMain ui;
    private final List<ResizablePrimitive> primitives = new ArrayList<>();
    private ResizablePrimitive selectedPrimitive;

    private final MainController controller;

    public MainView(MainController controller) {
        var root = new VBox();
        scene = new Scene(root, 800, 600);

        this.controller = controller;

        this.ui = new UiMain(root);
        this.ui.setup_ui();

        // Регистрация событий
        this.scene.setOnKeyPressed(this::keyPressed);
        this.ui.canvas.widthProperty().addListener((obs, oldVal, newVal) -> {
            this.draw(this.ui.canvas.getGraphicsContext2D());
        });
        this.ui.canvas.heightProperty().addListener((obs, oldVal, newVal) -> {
            this.draw(this.ui.canvas.getGraphicsContext2D());
        });
        this.ui.canvas.setOnMouseClicked(this::canvasMouseClicked);
        this.ui.strokeColor.setOnAction(this::strokeColorChanged);
        this.ui.fillColor.setOnAction(this::fillColorChanged);
        this.ui.borderSize.setOnAction(this::borderSizeChanged);
        this.ui.borderType.setOnAction(this::borderTypeChanged);
        this.ui.width.setOnAction(this::widthChanged);
        this.ui.height.setOnAction(this::heightChanged);

        this.ui.saveMenuItem.setOnAction(this::save);

        this.ui.exitMenuItem.setOnAction(event -> {
            this.controller.exit();
        });

        this.ui.instructionMenuItem.setOnAction(this::showInstruction);
    }

    public void modelChanged() {
        this.ui.borderSize.setText(String.valueOf(this.controller.getBorderSize()));
        this.ui.borderType.setValue(this.controller.getBorderType().toString());
        this.ui.strokeColor.setValue(Color.valueOf(this.controller.getBorderColor()));
        this.ui.fillColor.setValue(Color.valueOf(this.controller.getFillColor()));
        this.ui.width.setText(String.valueOf(this.controller.getPrimitiveWidth()));
        this.ui.height.setText(String.valueOf(this.controller.getPrimitiveHeight()));

        this.draw(this.ui.canvas.getGraphicsContext2D());
    }

    private void draw(GraphicsContext gc) {
        gc.clearRect(0, 0, gc.getCanvas().getWidth(), gc.getCanvas().getHeight());
        gc.setFill(Color.WHITE);
        gc.fillRect(0, 0, gc.getCanvas().getWidth(), gc.getCanvas().getHeight());

        // Отрисовка всех примитивов
        for (ResizablePrimitive primitive : primitives) {
            if (primitive == selectedPrimitive) {
                primitive.borderSize = this.controller.getBorderSize();
                primitive.borderColor = Color.valueOf(this.controller.getBorderColor());
                primitive.fillColor = Color.valueOf(this.controller.getFillColor());
                primitive.borderType = this.controller.getBorderType();
                primitive.width = this.controller.getPrimitiveWidth();
                primitive.height = this.controller.getPrimitiveHeight();
                primitive.setFocusVisible(true);
            }
            primitive.draw(gc);
        }
    }


    private void canvasMouseClicked(MouseEvent event) {
        if (event.getButton() == MouseButton.SECONDARY) {
            if (selectedPrimitive != null) {
                selectedPrimitive.setFocusVisible(false);
                this.selectedPrimitive = null;
            }

            PrimitiveType selectedPrimitive = this.controller.getSelectedPrimitive();
            int borderSize = this.controller.getBorderSize();
            Color borderColor = Color.valueOf(this.controller.getBorderColor());
            Color fillColor = Color.valueOf(this.controller.getFillColor());
            int shapeHeight = this.controller.getPrimitiveHeight();
            int shapeWidth = this.controller.getPrimitiveWidth();
            BorderType borderType = this.controller.getBorderType();

            ResizablePrimitive primitive = new ResizablePrimitive(
                event.getX() - (double) shapeWidth / 2,
                event.getY() - (double) shapeHeight / 2,
                shapeWidth,
                shapeHeight,
                selectedPrimitive,
                borderType,
                borderSize,
                borderColor,
                fillColor
            );

            this.selectedPrimitive = primitive;
            this.primitives.add(primitive);
            this.draw(this.ui.canvas.getGraphicsContext2D());
        } else if (event.getButton() == MouseButton.PRIMARY) {
            this.ui.canvas.requestFocus();
        }
    }

    private void showInstruction(ActionEvent event) {
        // messageBox
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Инструкция");
        alert.setHeaderText("Инструкция");
        alert.setContentText(
                "Для создания фигуры нажмите правую кнопку мыши в месте, где хотите создать фигуру.\n"
        );
        alert.showAndWait().ifPresent(rs -> {
            if (rs == ButtonType.OK) {
                System.out.println("Pressed OK.");
            }
        });

    }

    private void save(ActionEvent event) {
        FileChooser fc = new FileChooser();
        fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("Image files", "*.png"));
        File file = fc.showSaveDialog(null);

        if (file != null) {

            WritableImage writableImage = new WritableImage((int) this.ui.canvas.getWidth(), (int) this.ui.canvas.getHeight());
            this.ui.canvas.snapshot(null, writableImage);
            BufferedImage bufferedImage = SwingFXUtils.fromFXImage(writableImage, null);
            try {
                ImageIO.write(bufferedImage, "png", file);
            } catch (IOException ex) {
                System.out.println(ex.getMessage());
            }

        }
    }

    private void keyPressed(KeyEvent event){
        if (selectedPrimitive == null) return;

        if (event.getCode() == KeyCode.D) {
            selectedPrimitive.x += 10;
        } else if (event.getCode() == KeyCode.A) {
            selectedPrimitive.x -= 10;
        } else if (event.getCode() == KeyCode.W) {
            selectedPrimitive.y -= 10;
        } else if (event.getCode() == KeyCode.S) {
            selectedPrimitive.y += 10;
        } else if (event.getCode() == KeyCode.NUMPAD8) {
            controller.setPrimitiveHeight((int) (selectedPrimitive.height + 10));
        } else if (event.getCode() == KeyCode.NUMPAD2) {
            controller.setPrimitiveHeight((int) (selectedPrimitive.height - 10));
        } else if (event.getCode() == KeyCode.NUMPAD4) {
            controller.setPrimitiveWidth((int) (selectedPrimitive.width - 10));
        } else if (event.getCode() == KeyCode.NUMPAD6) {
            controller.setPrimitiveWidth((int) (selectedPrimitive.width + 10));
        }
        draw(this.ui.canvas.getGraphicsContext2D());
    }


    public void loaded() {
        for (PrimitiveType primitiveType: PrimitiveType.values()) {
            ToggleButton button = new ToggleButton();
            var primitive = new ResizablePrimitive(
                0,
                0,
                20,
                20,
                primitiveType,
                Color.valueOf("#000000")
            );
            if (primitiveType == PrimitiveType.ELLIPSE) {
                primitive.y = 4;
                primitive.width = 20;
                primitive.height = 16;
            }
            primitive.setFocusVisible(false);
            button.setGraphic(primitive.asIcon(20, 20));
            button.setMinSize(64, 64);
            button.setMaxSize(64, 64);
            button.setToggleGroup(this.ui.buttonGroup);
            button.setFocusTraversable(false);
            this.ui.toggleButtonLayout.getChildren().add(button);

            button.setOnAction(event -> {
                if (button.isSelected()) {
                    this.controller.setSelectedPrimitive(primitiveType);
                } else
                    this.controller.setSelectedPrimitive(null);
            });
        }
        for (BorderType borderType: BorderType.values()) {
            this.ui.borderType.getItems().add(borderType.toString());
        }
        modelChanged();
    }

    private void strokeColorChanged(Event event) {
        controller.setBorderColor(ui.strokeColor.getValue().toString());
    }

    private void fillColorChanged(Event event) {
        controller.setFillColor(ui.fillColor.getValue().toString());
    }

    private void borderSizeChanged(Event event) {
        controller.setBorderSize(Integer.parseInt(ui.borderSize.getText()));
    }

    private void borderTypeChanged(Event event) {
        controller.setBorderType(BorderType.valueOf(ui.borderType.getValue()));
    }

    private void widthChanged(Event event) {
        controller.setPrimitiveWidth(Integer.parseInt(ui.width.getText()));
    }

    private void heightChanged(Event event) {
        controller.setPrimitiveHeight(Integer.parseInt(ui.height.getText()));
    }
}

class ResizablePrimitive {
    double x;
    double y;

    double width;
    double height;

    PrimitiveType primitiveType;
    BorderType borderType;
    int borderSize;
    Color borderColor;
    Color fillColor;

    Boolean isFocusVisible = true;

    public ResizablePrimitive(
            double x,
            double y,
            double width,
            double height,
            PrimitiveType primitiveType,
            Color fillColor
    ) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.primitiveType = primitiveType;
        this.fillColor = fillColor;
    }

    public ResizablePrimitive(
            double x,
            double y,
            double width,
            double height,
            PrimitiveType primitiveType,
            BorderType borderType,
            int borderSize,
            Color borderColor,
            Color fillColor
    ) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.primitiveType = primitiveType;
        this.borderType = borderType;
        this.borderSize = borderSize;
        this.borderColor = borderColor;
        this.fillColor = fillColor;
    }

    public void setFocusVisible(boolean isVisible) {
        this.isFocusVisible = isVisible;
    }

    public void draw(GraphicsContext gc) {
        // Отрисовка примитива
        gc.setFill(fillColor);
        switch (primitiveType) {
            case LINE -> gc.strokeLine(x, y, x + width, y + height);
            case CIRCLE, ELLIPSE -> gc.fillOval(x, y, width, height);
            case RECTANGLE -> gc.fillRect(x, y, width, height);
        }

        if (borderType != null) {
            gc.setStroke(borderColor);
            gc.setLineWidth(borderSize);

            switch (borderType) {
                case DASHED -> gc.setLineDashes(10);
                case DOTTED -> gc.setLineDashes(2);
                case SOLID -> gc.setLineDashes(0);
            }
            switch (primitiveType) {
                case LINE -> gc.strokeLine(x, y, x + width, y + height);
                case CIRCLE, ELLIPSE -> gc.strokeOval(x, y, width, height);
                case RECTANGLE -> gc.strokeRect(x, y, width, height);
            }
        }

        if (isFocusVisible) {
            gc.setStroke(Color.BLACK);
            gc.setLineDashes(10);
            gc.setLineWidth(2);
            gc.setLineCap(StrokeLineCap.SQUARE);

            int padding = borderSize / 2 + 5;
            gc.strokeLine(x - padding, y - padding, x + width + padding, y - padding);
            gc.strokeLine(x - padding, y - padding, x - padding, y + height + padding);
            gc.strokeLine(x + width + padding, y - padding, x + width + padding, y + height + padding);
            gc.strokeLine(x - padding, y + height + padding, x + width + padding, y + height + padding);

        }

    }

    public Canvas asIcon(double a0, double a1) {
        Canvas canvas = new Canvas(a0, a1);
        GraphicsContext gc = canvas.getGraphicsContext2D();
        draw(gc);
        return canvas;
    }
}
