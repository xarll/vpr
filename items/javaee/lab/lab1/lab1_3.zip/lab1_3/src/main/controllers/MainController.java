package main.controllers;

import main.models.BorderType;
import main.models.MainModel;
import main.models.PrimitiveType;
import main.views.main.MainView;

public class MainController {
    private final MainModel model;
    public final MainView view;



    public MainController(MainModel model) {
        this.model = model;
        this.view = new MainView(this);

        this.model.addObserver(this.view);

        this.view.loaded();
    }

    public PrimitiveType getSelectedPrimitive() {
        return this.model.getSelectedPrimitive();
    }

    public void setSelectedPrimitive(PrimitiveType primitive) {
        this.model.setSelectedPrimitive(primitive);
    }

    public int getBorderSize() {
        return this.model.getBorderSize();
    }

    public String getBorderColor() {
        return this.model.getBorderColor();
    }

    public void setBorderColor(String color) {
        this.model.setBorderColor(color);
    }

    public BorderType getBorderType() {
        return this.model.getBorderType();
    }


    public void setBorderType(BorderType type) {
        this.model.setBorderType(type);
    }

    public void setBorderSize(int size) {
        this.model.setBorderSize(size);
    }

    public int getPrimitiveHeight() {
        return this.model.getPrimitiveHeight();
    }

    public int getPrimitiveWidth() {
        return this.model.getPrimitiveWidth();
    }

    public void setPrimitiveHeight(int height) {
        this.model.setPrimitiveHeight(height);
    }

    public void setPrimitiveWidth(int width) {
        this.model.setPrimitiveWidth(width);
    }

    public String getFillColor() {
        return this.model.getFillColor();
    }

    public void setFillColor(String color) {
        this.model.setFillColor(color);
    }

    public void exit() {
        System.exit(0);
    }
}
