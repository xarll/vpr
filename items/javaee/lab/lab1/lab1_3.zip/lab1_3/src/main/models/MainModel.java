package main.models;


import main.utils.DObserver;

import java.util.ArrayList;

public class MainModel {

    private final ArrayList<Object> observers;
    private int borderSize;
    private int shapeHeight;
    private int shapeWidth;

    private String borderColor;

    private String fillColor;

    private BorderType borderType;

    private PrimitiveType selectedPrimitive;

    public MainModel() {
        this.shapeHeight = 30;
        this.shapeWidth = 30;
        this.fillColor = "#000000";
        this.borderSize = 8;
        this.borderColor = "#FF0000";
        this.borderType = BorderType.SOLID;
        this.selectedPrimitive = PrimitiveType.LINE;

        this.observers = new ArrayList<>();
    }
    
    public PrimitiveType getSelectedPrimitive() {
        return selectedPrimitive;
    }
    
    public int getBorderSize() {
        return borderSize;
    }
    
    public String getBorderColor() {
        return borderColor;
    }
    
    public BorderType getBorderType() {
        return borderType;
    }
    
    public int getPrimitiveHeight() {
        return shapeHeight;
    }
    
    public int getPrimitiveWidth() {
        return shapeWidth;
    }
    
    public String getFillColor() {
        return fillColor;
    }

    public void setSelectedPrimitive(PrimitiveType primitive) {
        selectedPrimitive = primitive;
        notifyObservers();
    }
    

    public void setBorderColor(String color) {
        borderColor = color;
        notifyObservers();
    }


    public void setBorderType(BorderType type) {
        borderType = type;
        notifyObservers();
    }

    public void setBorderSize(int size) {
        borderSize = size;
        notifyObservers();
    }
    
    public void setPrimitiveHeight(int height) {
        shapeHeight = height;
        notifyObservers();
    }

    public void setPrimitiveWidth(int width) {
        shapeWidth = width;
        notifyObservers();
    }
    

    public void setFillColor(String color) {
        fillColor = color;
        notifyObservers();
    }


    public void addObserver(DObserver observer) {
        this.observers.add(observer);
    }

    public void notifyObservers() {
        for (Object observer : this.observers) {
            ((DObserver) observer).modelChanged();
        }
    }

    public void removeObserver(DObserver observer) {
        this.observers.remove(observer);
    }


}
