package main.models;

public enum BorderType {
    SOLID,
    DASHED,
    DOTTED
}
