package main.views.main;

import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;


public class UiMain {

    private final VBox root;
    MenuItem openMenuItem;

    MediaPlayer mediaPlayer;

    MediaView mediaView;

    HBox toggleButtonLayout;
    ToggleButton playButton;
    ToggleButton stopButton;

    Label timeStatus;

    Slider volumeSlider;

    UiMain(VBox root) {
        this.root = root;
    }

    void setup_ui() {
        root.setStyle("-fx-background-color: #d4cc71;");

        // Menubar
        var menuBar = new MenuBar();
        var fileMenu = new Menu("Файл");
        fileMenu.setStyle("-fx-font-size: 15px;");

        openMenuItem = new MenuItem("Открыть");
        openMenuItem.setStyle("-fx-font-size: 15px;");


        fileMenu.getItems().addAll(openMenuItem);
        menuBar.getMenus().addAll(fileMenu);
        root.getChildren().add(menuBar);

        // MediaPlayer
        mediaView = new MediaView();
        mediaView.setFitWidth(800);
        mediaView.setFitHeight(450);

        // MediaBar
        var mediaBar = new HBox();
        mediaBar.setPrefSize(800, 100);
        mediaBar.setPadding(new javafx.geometry.Insets(10, 10, 10, 10));
        mediaBar.setSpacing(10);
        mediaBar.setStyle("-fx-background-color: #959583;");

        // Play|Stop buttons
        var toggleGroup = new ToggleGroup();
        toggleButtonLayout = new HBox();
        toggleButtonLayout.setAlignment(Pos.CENTER);
        HBox.setMargin(toggleButtonLayout, new javafx.geometry.Insets(10, 10, 10, 10));

        playButton = new ToggleButton("Play");
        stopButton = new ToggleButton("Stop");

        playButton.setToggleGroup(toggleGroup);
        stopButton.setToggleGroup(toggleGroup);

        toggleButtonLayout.getChildren().addAll(playButton, stopButton);
        mediaBar.getChildren().add(toggleButtonLayout);

        // Time status bar
        var timeStatusBar = new HBox();
        timeStatusBar.setAlignment(Pos.CENTER);
        HBox.setMargin(timeStatusBar, new javafx.geometry.Insets(10, 10, 10, 10));
        mediaBar.getChildren().add(timeStatusBar);

        timeStatus = new Label("00:00:00/00:00:00");
        timeStatus.setStyle("-fx-font-size: 15px; -fx-text-fill: #ffffff;");
        timeStatusBar.getChildren().add(timeStatus);


        // Volume slider
        var VolumeBar = new HBox();
        VolumeBar.setAlignment(Pos.CENTER);
        HBox.setMargin(VolumeBar, new javafx.geometry.Insets(10, 10, 10, 10));
        VolumeBar.setSpacing(10);
        mediaBar.getChildren().add(VolumeBar);

        var volumeLabel = new Label("Громкость:");
        volumeLabel.setStyle("-fx-font-size: 15px; -fx-text-fill: #ffffff;");
        VolumeBar.getChildren().add(volumeLabel);

        volumeSlider = new Slider();
        volumeSlider.setPrefWidth(150);
        volumeSlider.setMinWidth(30);
        volumeSlider.setValue(100);
        volumeSlider.valueProperty().addListener((observable, oldValue, newValue) -> {
            if (mediaPlayer != null) {
                mediaPlayer.setVolume(volumeSlider.getValue() / 100);
            }
        });
        VolumeBar.getChildren().add(volumeSlider);



        root.getChildren().addAll(mediaView, mediaBar);
    }
}


