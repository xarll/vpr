package main.controllers;

import javafx.stage.Stage;
import main.models.MainModel;
import main.views.main.MainView;

public class MainController {
    private final MainModel model;
    public final MainView view;

    public MainController(MainModel model, Stage stage) {
        this.model = model;
        this.view = new MainView(this, stage);

        this.model.addObserver(this.view);

        this.view.loaded();
    }
}
