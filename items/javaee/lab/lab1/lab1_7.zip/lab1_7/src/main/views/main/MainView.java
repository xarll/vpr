package main.views.main;

import javafx.event.ActionEvent;
import javafx.scene.Scene;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import main.controllers.MainController;
import main.views.BaseView;

import java.io.File;


public class MainView extends BaseView {
    private final UiMain ui;
    private final MainController controller;

    private final Stage stage;

    public MainView(MainController controller, Stage stage) {
        var root = new VBox();
        scene = new Scene(root, 800, 550);

        this.controller = controller;
        this.stage = stage;

        this.ui = new UiMain(root);
        this.ui.setup_ui();

        // Регистрация событий
        this.ui.openMenuItem.setOnAction(this::openFileClicked);
        this.ui.playButton.setOnAction(this::playButtonClicked);
        this.ui.stopButton.setOnAction(this::stopButtonClicked);
    }

    private void stopButtonClicked(ActionEvent actionEvent) {
        if (ui.mediaPlayer != null) {
            ui.mediaPlayer.pause();
        }
    }

    private void playButtonClicked(ActionEvent actionEvent) {
        if (ui.mediaPlayer != null) {
            ui.mediaPlayer.play();
        }
    }

    public void modelChanged() {
        ui.stopButton.setSelected(true);
        if (ui.mediaPlayer != null) {
            stage.setTitle(ui.mediaPlayer.getMedia().getSource());
            ui.volumeSlider.setValue(ui.mediaPlayer.getVolume() * 50);
            ui.mediaPlayer.currentTimeProperty().addListener((observable, oldValue, newValue) -> {
                ui.timeStatus.setText(
                    String.format("%02d:%02d:%02d",
                            (int) newValue.toHours(),
                            (int) newValue.toMinutes(),
                            (int) newValue.toSeconds()
                    ) + " / " +
                        String.format("%02d:%02d:%02d",
                                (int) ui.mediaPlayer.getTotalDuration().toHours(),
                                (int) ui.mediaPlayer.getTotalDuration().toMinutes(),
                                (int) ui.mediaPlayer.getTotalDuration().toSeconds()
                        )
                );
            });
        }

    }

    public void loaded() {
        ui.playButton.setFocusTraversable(false);
        ui.stopButton.setFocusTraversable(false);
        modelChanged();
    }


    private void openFileClicked(ActionEvent actionEvent) {
        FileChooser fc = new FileChooser();
        fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("Video files", "*.mp4"));
        File file = fc.showOpenDialog(null);

        if (file != null) {
            var media = new javafx.scene.media.Media(file.toURI().toString());
            ui.mediaPlayer = new javafx.scene.media.MediaPlayer(media);
            ui.mediaView.setMediaPlayer(ui.mediaPlayer);
            modelChanged();
        }
    }
}