package com.example.buysell.services;

import com.example.buysell.models.Cart;
import com.example.buysell.repositories.CartRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Slf4j
public class CartService {
    private final CartRepository cartRepository;

    public CartService(CartRepository cartRepository) {
        this.cartRepository = cartRepository;
    }

    public void addToCart(Cart cart) {
        Cart cartItem = new Cart();
        log.info("Saving new Cart. userId: {}; productId: {}", cartItem.getProductId(), cartItem.getUserId());
        cartRepository.save(cart);
    }

    public List<Cart> getCartItemsByUserId(Long userId) {
        return cartRepository.findByUserId(userId);
    }

    // Другие методы с логикой для работы с корзиной...

}
