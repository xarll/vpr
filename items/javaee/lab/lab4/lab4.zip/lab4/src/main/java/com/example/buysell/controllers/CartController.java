package com.example.buysell.controllers;

import com.example.buysell.models.Cart;
import com.example.buysell.services.CartService;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/cart")
public class CartController {
    private final CartService cartService;

    public CartController(CartService cartService) {
        this.cartService = cartService;
    }

    @PostMapping("/add")
    public void addToCart(Cart cart) {
            System.out.println(cart);
            cartService.addToCart(cart);

    }

    @GetMapping("/{userId}")
    public String getCartItemsByUserId(@PathVariable Long userId) {
        List<Cart> cart = cartService.getCartItemsByUserId(userId);
        System.out.println("CART " + cart);
        return "products";
    }

}
