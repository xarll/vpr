package com.example.buysell.controllers;

import com.example.buysell.models.Product;
import com.example.buysell.models.User;
import com.example.buysell.models.enums.Role;
import com.example.buysell.services.ProductService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@Controller
@RequiredArgsConstructor
public class ProductController {
    private final ProductService productService;

    @GetMapping("/")
    public String products(@RequestParam(name = "title", required = false) String title, Model model, Authentication authentication) {
        model.addAttribute("products", productService.listProducts(title));
        if (authentication != null && authentication.isAuthenticated()) {

            User user = (User) authentication.getPrincipal();
            System.out.println("ROLESAS " + user.getRoles().contains(Role.ROLE_USER));
            model.addAttribute("userRole", user.getRoles().contains(Role.ROLE_USER));
            model.addAttribute("adminRole", user.getRoles().contains(Role.ROLE_ADMIN));
            model.addAttribute("isAuth", true);
            model.addAttribute("userDisplay", authentication.getName());
        } else {
            model.addAttribute("userDisplay", "Guest");
            model.addAttribute("userRole", false);
            model.addAttribute("isAuth", false);
            model.addAttribute("adminRole", false);
        }
        return "products";
    }

    @GetMapping("/product/{id}")
    public String productInfo(@PathVariable Long id, Model model, Authentication authentication) {
        Product product = productService.getProductById(id);
        model.addAttribute("product", product);
        model.addAttribute("images", product.getImages());
        if (authentication != null && authentication.isAuthenticated()) {

            User user = (User) authentication.getPrincipal();
            model.addAttribute("adminRole", user.getRoles().contains(Role.ROLE_ADMIN));
            model.addAttribute("userRole", user.getRoles().contains(Role.ROLE_USER));
        } else
        {
            model.addAttribute("userRole", false);
            model.addAttribute("adminRole", false);
        }
        return "product-info";
    }

    @PostMapping("/product/create")
    public String createProduct(Product product, Authentication authentication) throws IOException {
        if (authentication != null && authentication.isAuthenticated()) {
            User user = (User) authentication.getPrincipal();
            // Proceed with checking the user's roles and performing the necessary actions
            System.out.println(user);
            System.out.println(user.getRoles());
            if (user.getRoles().contains(Role.ROLE_USER) || user.getRoles().contains(Role.ROLE_ADMIN)) {
                productService.saveProduct(product);
                return "redirect:/";
            }
        }
        // Redirect or handle the case when the user is not authenticated or does not have the required role
        return "error";
    }

    @PostMapping("/product/delete/{id}")
    public String deleteProduct(@PathVariable Long id, @AuthenticationPrincipal User user) {
        // Проверяем роль пользователя
        if (user.getRoles().contains(Role.ROLE_ADMIN)) {
            productService.deleteProduct(id);
            return "redirect:/";
        }
        // Возвращаем ошибку доступа, если у пользователя нет административных прав
        return "error";
    }
}
