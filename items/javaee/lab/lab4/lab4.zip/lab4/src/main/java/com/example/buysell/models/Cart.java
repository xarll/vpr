package com.example.buysell.models;

import lombok.Data;

import javax.persistence.*;

@Entity
@Table(name = "carts")
@Data
public class Cart {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "user_id")
    private Long userId;

    @Column(name = "product_id")
    private Long productId;

    private int quantity;

    public void setId(Long id) {
        this.id = id;
    }
    public void setProductId(Long productId) {
        this.productId = productId;
    }
    public void setUserId(Long userId) {
        this.userId = userId;
    }
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}