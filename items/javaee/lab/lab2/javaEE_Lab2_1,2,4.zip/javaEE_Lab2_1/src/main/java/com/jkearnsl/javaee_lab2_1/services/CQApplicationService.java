package com.jkearnsl.javaee_lab2_1.services;

import com.jkearnsl.javaee_lab2_1.models.APIException;
import com.jkearnsl.javaee_lab2_1.models.ASResponse;
import com.jkearnsl.javaee_lab2_1.models.HttpResponse;
import com.jkearnsl.javaee_lab2_1.models.schemas.CurrencyQuote;
import com.jkearnsl.javaee_lab2_1.utils.CQParser;
import com.jkearnsl.javaee_lab2_1.utils.Http;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;

public class CQApplicationService {

    public static ASResponse<ArrayList<CurrencyQuote>, APIException> getCQ(LocalDate from, LocalDate to) {
        if (from == null) {
            return new ASResponse<>(null, new APIException("Не указана дата начала периода", 400));
        }

        String rawUrl = "https://www.cbr.ru/scripts/XML_daily.asp?date_req=" + from.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

        HttpResponse response;
        ArrayList<CurrencyQuote> quotes = new ArrayList<>();
        try {
            response = Http.get(rawUrl);
        } catch (IOException e) {
            return new ASResponse<>(null, new APIException("Не удалось получить данные", 500));
        }

        if (response.status != 200) {
            return new ASResponse<>(null, new APIException("Не удалось получить данные", 500));
        }

        if (to == null) {
            quotes = CQParser.parse(response.content, false);
            return new ASResponse<>(quotes, null);
        }

        ArrayList<CurrencyQuote> resp = CQParser.parse(response.content, false);
        String rawDynamicUrl = "https://www.cbr.ru/scripts/XML_dynamic.asp?date_req1=" + from.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) + "&date_req2=" + to.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) + "&VAL_NM_RQ=";
        if (resp == null) {
            return new ASResponse<>(null, new APIException("Не удалось получить данные", 500));
        }

        for (CurrencyQuote quote : resp) {
            try {
                response = Http.get(rawDynamicUrl + quote.id);
            } catch (IOException e) {
                System.err.println(e.getMessage());
                return new ASResponse<>(null, new APIException("Не удалось получить данные", 500));
            }
            
            if (response.status != 200) {
                System.err.println(response.content);
                return new ASResponse<>(null, new APIException("Не удалось получить данные", 500));
            }
            
            ArrayList<CurrencyQuote> localQuotes = CQParser.parse(response.content, true);
            if (localQuotes == null)
                quotes.add(quote);
            else {
                for (CurrencyQuote localQuote : localQuotes) {
                    localQuote.title = quote.title;
                }
                quotes.addAll(localQuotes);
            }
        }


        
        return new ASResponse<>(quotes, null);
    }
}
