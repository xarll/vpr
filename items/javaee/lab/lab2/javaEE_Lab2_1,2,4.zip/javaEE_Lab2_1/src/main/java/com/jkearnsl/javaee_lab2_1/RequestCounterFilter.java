package com.jkearnsl.javaee_lab2_1;

import com.jkearnsl.javaee_lab2_1.utils.RequestCounterBean;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.IOException;

public class RequestCounterFilter implements Filter {
    @Override
    public void init(FilterConfig filterConfig) {}

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpSession session = httpRequest.getSession(true);

        RequestCounterBean requestCounterBean = (RequestCounterBean) session.getAttribute("requestCounterBean");
        if (requestCounterBean == null) {
            requestCounterBean = new RequestCounterBean();
            session.setAttribute("requestCounterBean", requestCounterBean);
        }

        requestCounterBean.increment();
        chain.doFilter(request, response);
    }

    @Override
    public void destroy() {}
}