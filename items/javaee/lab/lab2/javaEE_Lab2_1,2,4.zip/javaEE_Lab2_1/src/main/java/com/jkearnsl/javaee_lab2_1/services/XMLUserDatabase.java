package com.jkearnsl.javaee_lab2_1.services;

import com.jkearnsl.javaee_lab2_1.models.schemas.User;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.UUID;

public class XMLUserDatabase {

    File filepath;

    public XMLUserDatabase(File filepath) {
        this.filepath = filepath;
    }

    public User createUser(String username, String first_name, String last_name, String hashed_password) throws IOException, XMLStreamException {
        XMLOutputFactory xmlOutputFactory = XMLOutputFactory.newInstance();
        XMLStreamWriter xmlStreamWriter = xmlOutputFactory.createXMLStreamWriter(new FileWriter(filepath));

        UUID id = UUID.randomUUID();

        // Find "Users" node and write new user
        xmlStreamWriter.writeStartDocument();
        xmlStreamWriter.writeStartElement("users");
        xmlStreamWriter.writeStartElement("user");
        xmlStreamWriter.writeAttribute("id", id.toString());
        xmlStreamWriter.writeStartElement("username");
        xmlStreamWriter.writeCharacters(username);
        xmlStreamWriter.writeEndElement();
        xmlStreamWriter.writeStartElement("first_name");
        xmlStreamWriter.writeCharacters(first_name);
        xmlStreamWriter.writeEndElement();
        xmlStreamWriter.writeStartElement("last_name");
        xmlStreamWriter.writeCharacters(last_name);
        xmlStreamWriter.writeEndElement();
        xmlStreamWriter.writeStartElement("hashed_password");
        xmlStreamWriter.writeCharacters(hashed_password);
        xmlStreamWriter.writeEndElement();
        xmlStreamWriter.writeEndElement();
        xmlStreamWriter.writeEndDocument();
        xmlStreamWriter.flush();
        xmlStreamWriter.close();

        return new User(id, username, first_name, last_name, hashed_password);
    }

    public User get(UUID id) {
        return getBy("id", id);
    }

    public User getUserByUsername(String username) {
        return getBy("username", username);
    }

    private User getBy(String key, Object searchValue){
        try {
            DocumentBuilder documentBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            Document document = documentBuilder.parse(filepath);

            NodeList nodeList = document.getElementsByTagName("user");

            for (int i = 0; i < nodeList.getLength(); i++) {
                Node node = nodeList.item(i);

                if (node.getNodeType() == Node.ELEMENT_NODE) {
                    Node keyNode = node.getChildNodes().item(0);

                    boolean isInNodeName = (keyNode.getNodeName().equals(key) && keyNode.getTextContent().equals(searchValue.toString()));
                    boolean isInNodeAttributes = (
                            node.getAttributes().getNamedItem(key) != null && node.getAttributes().getNamedItem(key).getTextContent().equals(searchValue.toString())
                    );

                    if (isInNodeName || isInNodeAttributes) {
                        Node idNode = node.getAttributes().getNamedItem("id");
                        Node usernameNode = node.getChildNodes().item(0);
                        Node first_nameNode = node.getChildNodes().item(1);
                        Node last_nameNode = node.getChildNodes().item(2);
                        Node passwordNode = node.getChildNodes().item(3);

                        return new User(
                                UUID.fromString(idNode.getTextContent()),
                                usernameNode.getTextContent(),
                                first_nameNode.getTextContent(),
                                last_nameNode.getTextContent(),
                                passwordNode.getTextContent()
                        );
                    }
                }
            }
        } catch (ParserConfigurationException error) {
            error.printStackTrace();
        } catch (IOException error) {
            error.printStackTrace();
        } catch (SAXException error) {
            error.printStackTrace();
        }
        return null;
    }
}
