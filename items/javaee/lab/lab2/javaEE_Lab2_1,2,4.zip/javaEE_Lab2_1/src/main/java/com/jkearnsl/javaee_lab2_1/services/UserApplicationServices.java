package com.jkearnsl.javaee_lab2_1.services;

import com.jkearnsl.javaee_lab2_1.models.APIException;
import com.jkearnsl.javaee_lab2_1.models.ASResponse;
import com.jkearnsl.javaee_lab2_1.models.schemas.User;
import com.jkearnsl.javaee_lab2_1.models.schemas.UserSignIn;
import com.jkearnsl.javaee_lab2_1.models.schemas.UserSignUp;
import com.jkearnsl.javaee_lab2_1.utils.HashPassword;

import javax.servlet.http.HttpSession;
import java.util.UUID;

public class UserApplicationServices {

    public static ASResponse<User, APIException> signIn(UserSignIn data, XMLUserDatabase database, HttpSession session) {
        if (session.getAttribute("user_id") != null) {
            return new ASResponse<>(null, new APIException("Пользователь уже авторизован", 400));
        }

        if (data.username == null || data.username.isEmpty()) {
            return new ASResponse<>(null, new APIException("Имя пользователя не может быть пустым", 400));
        }

        if (data.password == null || data.password.isEmpty()) {
            return new ASResponse<>(null, new APIException("Пароль не может быть пустым", 400));
        }

        Integer countOfAttempts = (Integer) session.getAttribute("countOfAttempts");
        if (countOfAttempts == null) {
            countOfAttempts = 0;
        }

        if (countOfAttempts >= 3) {
            return new ASResponse<>(null, new APIException("Превышено количество попыток входа", 400));
        }

        session.setAttribute("countOfAttempts", countOfAttempts + 1);
        session.setMaxInactiveInterval(60 * 60); // 1 Час

        User user = database.getUserByUsername(data.username.toLowerCase());
        if (user == null) {
            return new ASResponse<>(null, new APIException("Пользователь не найден", 404));
        }
        if (!HashPassword.checkPassword(data.password, user.hashed_password)) {
            return new ASResponse<>(null, new APIException("Некорректный пароль", 401));
        }
        session.setAttribute("countOfAttempts", 0);
        session.setMaxInactiveInterval(60 * 60 * 24 * 30); // 30 Дней
        session.setAttribute("user_id", user.id);
        return new ASResponse<>(user, null);
    }

    public static ASResponse<User, APIException> signUp(UserSignUp data, XMLUserDatabase database, HttpSession session) {
        if (session.getAttribute("user_id") != null) {
            return new ASResponse<>(null, new APIException("Пользователь уже авторизован", 400));
        }

        if (data.username == null || data.username.isEmpty()) {
            return new ASResponse<>(null, new APIException("Имя пользователя не может быть пустым", 400));
        }

        if (data.password == null || data.password.isEmpty()) {
            return new ASResponse<>(null, new APIException("Пароль не может быть пустым", 400));
        }

        if (data.firstname == null || data.firstname.isEmpty()) {
            return new ASResponse<>(null, new APIException("Имя не может быть пустым", 400));
        }

        if (data.lastname == null || data.lastname.isEmpty()) {
            return new ASResponse<>(null, new APIException("Фамилия не может быть пустой", 400));
        }

        if (data.password.length() < 8) {
            return new ASResponse<>(null, new APIException("Пароль должен быть не менее 8 символов", 400));
        }

        if (data.username.length() < 4) {
            return new ASResponse<>(null, new APIException("Имя пользователя должно быть не менее 4 символов", 400));
        }

        if (database.getUserByUsername(data.username.toLowerCase()) != null) {
            return new ASResponse<>(null, new APIException("Пользователь с таким именем уже существует", 400));
        }

        String hashed_password = HashPassword.hashPassword(data.password);

        User user;
        try {
            user = database.createUser(data.username.toLowerCase(), data.firstname, data.lastname, hashed_password);
        } catch (Exception error) {
            return new ASResponse<>(null, new APIException("Ошибка при создании пользователя", 500));
        }
        return new ASResponse<>(user, null);
    }

    public static ASResponse<User, APIException> getCurrentUser(HttpSession session, XMLUserDatabase database) {
        UUID user_id = (UUID) session.getAttribute("user_id");
        if (user_id == null) {
            return new ASResponse<>(null, new APIException("Пользователь не авторизован", 401));
        }
        User user = database.get(user_id);
        if (user == null) {
            return new ASResponse<>(null, new APIException("Пользователь не найден", 404));
        }
        return new ASResponse<>(user, null);
    }

    public static void logout(HttpSession session) {
        session.invalidate();
    }
}
