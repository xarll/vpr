package com.jkearnsl.javaee_lab2_1;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jkearnsl.javaee_lab2_1.models.APIException;
import com.jkearnsl.javaee_lab2_1.models.ASResponse;
import com.jkearnsl.javaee_lab2_1.models.schemas.CurrencyQuote;
import com.jkearnsl.javaee_lab2_1.models.schemas.User;
import com.jkearnsl.javaee_lab2_1.models.schemas.UserSignIn;
import com.jkearnsl.javaee_lab2_1.services.CQApplicationService;
import com.jkearnsl.javaee_lab2_1.services.UserApplicationServices;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

@WebServlet(name = "CurrencyQuotesPage", value = "/currencyQuotes")
public class CurrencyQuotesPage extends HttpServlet {

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        request.setAttribute("from", LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
        RequestDispatcher dispatcher = request.getRequestDispatcher("currencyQuotes.jsp");
        dispatcher.forward(request, response);
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        // Pre-process
        response.setCharacterEncoding("UTF-8");
        LocalDate from = null;
        LocalDate to = null;

        if (request.getParameter("from") != null && !request.getParameter("from").isEmpty()) {
            from = LocalDate.parse(request.getParameter("from"));
        }

        if (request.getParameter("to") != null && !request.getParameter("to").isEmpty()) {
            to = LocalDate.parse(request.getParameter("to"));
        }


        // Process
        ASResponse<ArrayList<CurrencyQuote>, APIException> resp = CQApplicationService.getCQ(from, to);


        // Post-Process
        if (resp.exception != null) {
            response.setStatus(resp.exception.code);
            response.getWriter().print(resp.exception.message);
            return;
        }
        request.setAttribute("quotes", resp.data);
        if (from != null) {
            request.setAttribute("from", from.format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
        }
        if (to != null) {
            request.setAttribute("to", to.format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
        }

        RequestDispatcher dispatcher = request.getRequestDispatcher("currencyQuotes.jsp");
        dispatcher.forward(request, response);
    }
}
