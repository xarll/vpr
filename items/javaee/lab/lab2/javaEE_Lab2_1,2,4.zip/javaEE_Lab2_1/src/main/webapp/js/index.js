
let welcomeLabel = document.getElementById('welcome');
let signItem = document.getElementById('signItem');
let logoutItem = document.getElementById('logoutItem');


function init() {
    fetch("/api/user")
        .then(function (response) {
            if (response.ok) {
                response.json().then(function (json) {
                    welcomeLabel.innerHTML = "Добро пожаловать, " + json.firstname + " " + json.lastname + "!";
                    signItem.classList.add("is-hidden");
                });
            } else {
                response.text().then(function (text) {
                    console.log(text);
                    welcomeLabel.innerHTML = "Добро пожаловать, гость!";
                    logoutItem.classList.add("is-hidden");
                });
            }
        });
}

init();

logoutItem.addEventListener("click", function () {
    fetch("/api/logout", {method: "POST"}).then(function (response) {
            if (response.ok) {
                window.location.href = "/";
            } else {
                response.text().then(function (text) {
                    console.log(text);
                });
            }
        });
});