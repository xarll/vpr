package com.jkearnsl.javaee_lab2_1.models.schemas;

import java.util.UUID;

public class User {
    public UUID id;
    public String username;
    public String firstname;
    public String lastname;
    public String hashed_password;

    public User(UUID id, String username, String firstname, String lastname, String hashed_password) {
        this.id = id;
        this.username = username;
        this.firstname = firstname;
        this.lastname = lastname;
        this.hashed_password = hashed_password;
    }
}
