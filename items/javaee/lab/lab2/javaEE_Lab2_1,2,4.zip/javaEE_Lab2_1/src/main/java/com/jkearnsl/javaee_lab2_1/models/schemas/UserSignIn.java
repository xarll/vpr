package com.jkearnsl.javaee_lab2_1.models.schemas;

public class UserSignIn {
    public String username;
    public String password;

    public UserSignIn(String username, String password) {
        this.username = username;
        this.password = password;
    }
}
