package com.jkearnsl.javaee_lab2_1;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jkearnsl.javaee_lab2_1.models.APIException;
import com.jkearnsl.javaee_lab2_1.models.ASResponse;
import com.jkearnsl.javaee_lab2_1.models.schemas.User;
import com.jkearnsl.javaee_lab2_1.services.UserApplicationServices;
import com.jkearnsl.javaee_lab2_1.services.XMLUserDatabase;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;


@WebServlet(name = "User", value = "/api/user")
public class UserManagement extends HttpServlet {

    XMLUserDatabase userDatabase;


    public void init() {
        // Это должно быть в глобал скоупе, но я не знаю как это сделать

        userDatabase = new XMLUserDatabase(new File("/home/jkearnsl/IdeaProjects/javaEE_Lab2_1/userbase.xml"));

    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        // Pre-process
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        HttpSession session = request.getSession();


        // Process
        ASResponse<User, APIException> resp = UserApplicationServices.getCurrentUser(session, userDatabase);


        // Post-Process
        if (resp.exception != null) {
            response.setStatus(resp.exception.code);
            response.getWriter().print(resp.exception.message);
            return;
        }
        ObjectMapper objectMapper = new ObjectMapper();
        String jsonString = objectMapper.writeValueAsString(resp.data);
        PrintWriter out = response.getWriter();
        out.print(jsonString);
        out.flush();
        out.close();
    }

}