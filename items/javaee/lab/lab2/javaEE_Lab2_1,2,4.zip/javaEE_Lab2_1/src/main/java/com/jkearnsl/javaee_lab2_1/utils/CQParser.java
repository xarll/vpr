package com.jkearnsl.javaee_lab2_1.utils;

import com.jkearnsl.javaee_lab2_1.models.schemas.CurrencyQuote;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.StringReader;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class CQParser {

    public static ArrayList<CurrencyQuote> parse(String rawXml, boolean isDynamic) {
        ArrayList<CurrencyQuote> result = new ArrayList<>();

        NodeList nodeList;
        Document document;
        Node root;
        try {
            DocumentBuilder documentBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            document = documentBuilder.parse(new InputSource(new StringReader(rawXml)));

            if (isDynamic) {
                nodeList = document.getElementsByTagName("Record");
            } else {
                nodeList = document.getElementsByTagName("Valute");
            }
            root = (document.getElementsByTagName("ValCurs")).item(0);
        } catch (Exception e) {
            System.err.println(e.getMessage());
            return null;
        }

        for (int i = 0; i < nodeList.getLength(); i++) {
            Node node = nodeList.item(i);

            if (node.getNodeType() == Node.ELEMENT_NODE) {
                Node keyNode = node.getChildNodes().item(0);

                if (keyNode.getNodeType() == Node.ELEMENT_NODE) {
                    String id;
                    String title;
                    double value;
                    double vunitRate;
                    LocalDate date;

                    if (isDynamic) {
                        id = node.getAttributes().getNamedItem("Id").getTextContent();
                        title = null;
                        value = Double.parseDouble(node.getChildNodes().item(1).getTextContent().replace(",", "."));
                        vunitRate = Double.parseDouble(node.getChildNodes().item(2).getTextContent().replace(",", "."));
                        date = LocalDate.parse(node.getAttributes().getNamedItem("Date").getTextContent(), DateTimeFormatter.ofPattern("dd.MM.yyyy"));
                    } else {
                        id = node.getAttributes().getNamedItem("ID").getTextContent();
                        title = node.getChildNodes().item(1).getTextContent();
                        value = Double.parseDouble(node.getChildNodes().item(4).getTextContent().replace(",", "."));
                        vunitRate = Double.parseDouble(node.getChildNodes().item(5).getTextContent().replace(",", "."));
                        date = LocalDate.parse(root.getAttributes().getNamedItem("Date").getTextContent(), DateTimeFormatter.ofPattern("dd.MM.yyyy"));
                    }
                    result.add(new CurrencyQuote(id, title, value, vunitRate, date ));
                }
            }
        }
        return result;
    }


}