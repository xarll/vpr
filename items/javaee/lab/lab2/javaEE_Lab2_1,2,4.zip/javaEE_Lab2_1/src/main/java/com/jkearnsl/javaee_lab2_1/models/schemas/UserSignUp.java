package com.jkearnsl.javaee_lab2_1.models.schemas;

public class UserSignUp {
    public String username;
    public String firstname;
    public String lastname;
    public String password;

    public UserSignUp(String username, String firstname, String lastname, String password) {
        this.username = username;
        this.firstname = firstname;
        this.lastname = lastname;
        this.password = password;
    }
}
