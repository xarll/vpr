package com.jkearnsl.javaee_lab2_1.utils;

import com.jkearnsl.javaee_lab2_1.models.HttpResponse;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

public class Http {

    public static HttpResponse get(String urlStr) throws IOException {
        URL url = new URL(urlStr);

        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("GET");
        connection.setRequestProperty("User-Agent", "Mozilla/5.0");
        connection.setConnectTimeout(1000);
        connection.setRequestMethod("GET");

        int status = connection.getResponseCode();

        InputStream inputStream = connection.getInputStream();

        // Читаем ответ
        byte[] buffer = new byte[1024];
        int bytesRead;
        StringBuilder responseContent = new StringBuilder();
        while ((bytesRead = inputStream.read(buffer)) != -1) {
            responseContent.append(new String(buffer, 0, bytesRead));
        }
        inputStream.close();

        return new HttpResponse(responseContent.toString(), status);
    }
}
