package com.jkearnsl.javaee_lab2_1;

import com.jkearnsl.javaee_lab2_1.services.UserApplicationServices;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet(name = "Logout", value = "/api/logout")
public class Logout extends HttpServlet {

    public void doPost(HttpServletRequest request, HttpServletResponse response) {
        // Pre-process
        HttpSession session = request.getSession();

        // Process
        UserApplicationServices.logout(session);

    }

}