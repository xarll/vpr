package com.jkearnsl.javaee_lab2_1.utils;

import java.io.Serializable;

public class RequestCounterBean implements Serializable {
    private int count = 0;

    public int getCount() {
        return count;
    }

    public void increment() {
        count++;
    }
}
