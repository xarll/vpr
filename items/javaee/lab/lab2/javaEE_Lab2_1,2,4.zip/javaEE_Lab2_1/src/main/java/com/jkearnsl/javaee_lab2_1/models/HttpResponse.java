package com.jkearnsl.javaee_lab2_1.models;


public class HttpResponse {
    public String content;
    public int status;

    public HttpResponse(String content, int status) {
        this.content = content;
        this.status = status;
    }
}
