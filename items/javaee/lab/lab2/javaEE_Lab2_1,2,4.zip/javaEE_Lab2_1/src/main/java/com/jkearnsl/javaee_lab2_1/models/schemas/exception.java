package com.jkearnsl.javaee_lab2_1.models.schemas;

public class exception {
}
