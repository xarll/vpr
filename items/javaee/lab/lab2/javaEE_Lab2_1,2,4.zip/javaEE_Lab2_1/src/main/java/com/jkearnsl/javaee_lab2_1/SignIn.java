package com.jkearnsl.javaee_lab2_1;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jkearnsl.javaee_lab2_1.models.APIException;
import com.jkearnsl.javaee_lab2_1.models.ASResponse;
import com.jkearnsl.javaee_lab2_1.models.schemas.User;
import com.jkearnsl.javaee_lab2_1.models.schemas.UserSignIn;
import com.jkearnsl.javaee_lab2_1.services.UserApplicationServices;
import com.jkearnsl.javaee_lab2_1.services.XMLUserDatabase;

import java.io.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;


@WebServlet(name = "SignIn", value = "/api/signIn")
public class SignIn extends HttpServlet {

    XMLUserDatabase userDatabase;


    public void init() {
        // Это должно быть в глобал скоупе, но я не знаю как это сделать

        userDatabase = new XMLUserDatabase(new File("/home/jkearnsl/IdeaProjects/javaEE_Lab2_1/userbase.xml"));

    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        // Pre-process
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        HttpSession session = request.getSession();


        // Process
        ASResponse<User, APIException> resp = UserApplicationServices.signIn(
            new UserSignIn(
                request.getParameter("username"),
                request.getParameter("password")
            ),
            userDatabase,
            session
        );


        // Post-Process
        if (resp.exception != null) {
            response.setStatus(resp.exception.code);
            response.getWriter().print(resp.exception.message);
            return;
        }
        ObjectMapper objectMapper = new ObjectMapper();
        String jsonString = objectMapper.writeValueAsString(resp.data);
        PrintWriter out = response.getWriter();
        out.print(jsonString);
        out.flush();
        out.close();
    }

}