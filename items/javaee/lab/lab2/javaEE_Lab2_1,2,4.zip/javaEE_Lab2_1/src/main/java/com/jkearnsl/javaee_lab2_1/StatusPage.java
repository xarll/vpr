package com.jkearnsl.javaee_lab2_1;

import com.jkearnsl.javaee_lab2_1.utils.RequestCounterBean;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Date;

@WebServlet(name = "StatusPage", value = "/status")
public class StatusPage extends HttpServlet {
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();


        Date currentTime = new Date();

        RequestCounterBean requestCounterBean = (RequestCounterBean) session.getAttribute("requestCounterBean");

        // Передаем данные в атрибуты запроса
        request.setAttribute("sessionId", session.getId());
        request.setAttribute("sessionCreationTime", new Date(session.getCreationTime()));
        request.setAttribute("currentTime", currentTime);
        request.setAttribute("requestCount", requestCounterBean.getCount());

        // Перенаправляем на JSP страницу
        request.getRequestDispatcher("status.jsp").forward(request, response);
    }
}