package com.jkearnsl.javaee_lab2_1.models.schemas;

import java.time.LocalDate;
import java.util.Date;

public class CurrencyQuote {

    public String id;
    public String title;
    public double value;
    public double vunitRate;
    public LocalDate date;

    public CurrencyQuote(String id, String title, double value, double vunitRate, LocalDate date) {
        this.id = id;
        this.title = title;
        this.value = value;
        this.vunitRate = vunitRate;
        this.date = date;
    }
}
