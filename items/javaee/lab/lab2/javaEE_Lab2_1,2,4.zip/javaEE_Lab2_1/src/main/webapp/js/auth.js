
let isSignInState = true;
let errorBox = document.getElementById("errorBox");
let errorMessageBox = document.getElementById("errorMessageBox");

function signClicked(event) {
    event.preventDefault();
    let signBtn = event.target;
    errorBox.classList.add("is-hidden");

    signBtn.classList.add("is-loading");

    let url;
    let method;
    let params;

    if (isSignInState) {
        let username = document.getElementById("username").value;
        let password = document.getElementById("password").value;

        url = "/api/signIn";
        method = "POST";
        params = {
            "username": username,
            "password": password
        };
    } else {
        let username = document.getElementById("username").value;
        let firstname = document.getElementById("firstname").value;
        let lastname = document.getElementById("lastname").value;
        let password = document.getElementById("password").value;

        url = "/api/signUp";
        method = "POST";
        params = {
            "username": username,
            "firstname": firstname,
            "lastname": lastname,
            "password": password
        };
    }
    console.log(params);

    // http request
    setTimeout(function () {
        fetch(url + "?" + new URLSearchParams(params), {
            method: method,
        }).then(function (response) {
            if (response.ok) {
                response.json().then(function (json) {
                    signBtn.classList.remove("is-loading");
                    console.log(json);
                    window.location.href = "/";
                });
            } else {
                response.text().then(function (text) {
                    signBtn.classList.remove("is-loading");
                    console.log(text);

                    errorBox.classList.remove("is-hidden");
                    errorMessageBox.innerHTML = text;

                }) ;
            }
        } )
    }, 1000);
}



function signInToggleClicked(event) {
    event.preventDefault();
    let signInToggle = document.getElementById("signInToggle");
    let signUpToggle = document.getElementById("signUpToggle");

    signInToggle.classList.add("is-active");
    signUpToggle.classList.remove("is-active");

    document.getElementById("signBtn").innerHTML = "SignIn";
    document.getElementById("firstnameField").classList.add("is-hidden");
    document.getElementById("lastnameField").classList.add("is-hidden");

    isSignInState = !isSignInState;
    errorBox.classList.add("is-hidden");
}

function signUpToggleClicked(event) {
    event.preventDefault();
    let signInToggle = document.getElementById("signInToggle");
    let signUpToggle = document.getElementById("signUpToggle");

    signInToggle.classList.remove("is-active");
    signUpToggle.classList.add("is-active");

    document.getElementById("signBtn").innerHTML = "SignUp";
    document.getElementById("firstnameField").classList.remove("is-hidden");
    document.getElementById("lastnameField").classList.remove("is-hidden");

    isSignInState = !isSignInState;
    errorBox.classList.add("is-hidden");
}


document.getElementById("signBtn").addEventListener("click", signClicked, false);
document.getElementById("signInToggle").addEventListener("click", signInToggleClicked, false);
document.getElementById("signUpToggle").addEventListener("click", signUpToggleClicked, false);

