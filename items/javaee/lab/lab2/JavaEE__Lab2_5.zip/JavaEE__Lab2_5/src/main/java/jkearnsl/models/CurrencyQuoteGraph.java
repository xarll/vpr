package jkearnsl.models;


import java.util.ArrayList;

public class CurrencyQuoteGraph {
    public ArrayList<Double> y;
    public ArrayList<Integer> x;
    public String label;
    public int width;
    public String id;
    public String color;

    public CurrencyQuoteGraph(
            String id,
            ArrayList<Double> values,
            String label,
            int width,
            String color
    ) {
        this.id = id;
        this.y = values;
        this.label = label;
        this.width = width;
        this.color = color;

        this.calculate();
    }

    public void calculate() {
        x = new ArrayList<>();
        for (int i = 0; i < y.size(); i++) {
            x.add(i);
        }
    }

    public ArrayList<Integer> getX() {
        return this.x;
    }

    public ArrayList<Double> getY() {
        return this.y;
    }
}
