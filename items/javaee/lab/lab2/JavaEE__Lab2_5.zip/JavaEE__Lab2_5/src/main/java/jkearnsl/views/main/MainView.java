package jkearnsl.views.main;

import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Circle;
import jkearnsl.controllers.MainController;
import jkearnsl.models.CurrencyQuoteGraph;
import jkearnsl.views.BaseView;

import java.util.Random;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


public class MainView extends BaseView {
    private final UiMain ui;
    private final MainController controller;

    private VBox root;


    public MainView(MainController controller) {
        root = new VBox();
        scene = new Scene(root, 800, 600);

        this.controller = controller;

        this.ui = new UiMain(root);
        this.ui.setup_ui();

        // Регистрация событий
        ui.send.setOnAction(this::sendClicked);
    }

    private void sendClicked(ActionEvent actionEvent) {
        LocalDate fromDate = ui.fromDate.getValue();
        LocalDate toDate = ui.toDate.getValue();

        if (fromDate == null) {
            ui.fromDate.requestFocus();
            return;
        }
        controller.loadQuotes(fromDate, toDate);
    }

    public void modelChanged() {
        ArrayList<CurrencyQuote> quotes = controller.getQuotes();
        boolean isDynamic = controller.getIsDynamicState();

        if (isDynamic) {
            ui.respContainer.getChildren().clear();
            ui.respContainer.getChildren().add(ui.graphContainer);

            HashMap<String, ArrayList<CurrencyQuote>> dict = new HashMap<>();
            HashMap<String, String> colorMap = new HashMap<>();
            for (CurrencyQuote quote: quotes) {
                if (dict.get(quote.getId()) == null) {
                    dict.put(quote.getId(), new ArrayList<>());

                    Random rand = new Random();
                    int R = (int)(Math.random()*256);
                    int G = (int)(Math.random()*256);
                    int B= (int)(Math.random()*256);

                    colorMap.put(quote.getId(), String.format("#%02x%02x%02x", R, G, B));
                }
                else
                    dict.get(quote.getId()).add(quote);
            }
            ui.lineChart.getData().clear();
            int counter = 0;
            for (Map.Entry<String,ArrayList<CurrencyQuote>> entry: dict.entrySet()) {
                ArrayList<CurrencyQuote> array = entry.getValue();

                if (!array.isEmpty()) {
                    if(counter >= 10)
                        break;

                    counter++;
                    ArrayList<Double> values = new ArrayList<>();
                    for (CurrencyQuote element : array) {
                        values.add(Double.parseDouble(element.getValue()));
                    }

                    drawGraphic(
                            new CurrencyQuoteGraph(entry.getKey(), values, array.get(0).getTitle(), 1, colorMap.get(array.get(0).getId()))
                    );
                }
            }

        } else {
            ui.respContainer.getChildren().clear();
            ui.respContainer.getChildren().add(ui.tableView);
            ui.tableView.setItems(FXCollections.observableArrayList(quotes));
        }

    }

    private void drawGraphic(CurrencyQuoteGraph graph) {
        var series = new XYChart.Series<Number, Number>();
        series.setName(graph.label);
        for (int i = 0; i < graph.getX().size(); i++) {
            series.getData().add(new XYChart.Data<>(graph.getX().get(i), graph.getY().get(i)));
        }
        ui.lineChart.getData().add(series);

        // Краска и стили
        Node line = series.getNode().lookup(".chart-series-line");
        line.setStyle("-fx-stroke: " + graph.color + ";");
        for (XYChart.Data<Number, Number> data : series.getData()) {
            Node point = data.getNode();
            point.setStyle(
                    "-fx-background-color: " + graph.color +
                            "; -fx-scale-x: " + graph.width +
                            "px; -fx-scale-y: " + graph.width + "px;"
            );
        }

        // Кастомный элемент легенды
        var legendColorShape = new Circle(10);
        legendColorShape.setFill(Paint.valueOf(graph.color));

        var legendLabel = new Label(graph.label);

        var legendItem = new HBox(legendColorShape, legendLabel);
        HBox.setMargin(legendItem, new javafx.geometry.Insets(10, 10, 20, 10));
        legendItem.setAlignment(Pos.CENTER);
        legendItem.setSpacing(5);

        ui.legendContainer.getChildren().add(legendItem);
    }

    public void loaded() {
        LocalDate from = LocalDate.now();
        controller.loadQuotes(from, null);
    }
}