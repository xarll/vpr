package jkearnsl.models;


import jkearnsl.utils.DObserver;
import jkearnsl.views.main.CurrencyQuote;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class MainModel {

    private final ArrayList<Object> observers;

    private ArrayList<CurrencyQuote> quotes;

    private boolean isDynamic;




    public MainModel() {
        this.observers = new ArrayList<>();
        this.isDynamic = false;
    }

    public ArrayList<CurrencyQuote> getQuotes() {
        return quotes;
    }

    public boolean getIsDynamic() {
        return isDynamic;
    }

    public void loadQuotes(LocalDate from, LocalDate to) {
        try {
            String rawStr = "http://localhost:8080/api/currencyQuotes?from=" + from.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
            if (to != null) {
                this.isDynamic = true;
                rawStr = rawStr + "&to=" + to.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
            }
            URL url = new URL(rawStr);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setRequestProperty("User-Agent", "Mozilla/5.0");

            int status = connection.getResponseCode();

            InputStream inputStream = connection.getInputStream();

            byte[] buffer = new byte[1024];
            int bytesRead;
            StringBuilder responseContent = new StringBuilder();
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                responseContent.append(new String(buffer, 0, bytesRead));
            }
            inputStream.close();

            String rawResponse = responseContent.toString();

            if (status != 200) {
                return;
            }
            
            quotes = new ArrayList<>();
            JSONArray arr = new JSONArray(rawResponse);
            for (int i = 0; i < arr.length(); i++)
            {
                JSONObject element = arr.getJSONObject(i);

                JSONArray rawData = element.getJSONArray("date");
                int year = rawData.getInt(0);
                int month = rawData.getInt(1);
                int day = rawData.getInt(2);
                String strDate = String.valueOf(year) + "." + String.valueOf(month) + "." + String.valueOf(day);

                quotes.add(
                    new CurrencyQuote(
                        element.getString("id"),
                        element.getString("title"),
                        String.valueOf(element.getDouble("value")),
                        String.valueOf(element.getDouble("vunitRate")),
                        strDate
                    )
                );
            }
            notifyObservers();
        } catch (IOException errorObj) {
            System.err.println(errorObj.getMessage());
            return;
        }
    }

    public void addObserver(DObserver observer) {
        this.observers.add(observer);
    }

    public void notifyObservers() {
        for (Object observer : this.observers) {
            ((DObserver) observer).modelChanged();
        }
    }

    public void removeObserver(DObserver observer) {
        this.observers.remove(observer);
    }
}
