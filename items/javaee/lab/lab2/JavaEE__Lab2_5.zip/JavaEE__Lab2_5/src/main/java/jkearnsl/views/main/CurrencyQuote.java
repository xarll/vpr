package jkearnsl.views.main;


import javafx.beans.property.*;

import java.time.LocalDate;

public class CurrencyQuote {
    private final StringProperty id;
    private final StringProperty title;
    private final StringProperty value;
    private final StringProperty vunitRate;
    private final StringProperty date;

    public CurrencyQuote(String id, String title, String value, String vunitRate, String date) {
        this.id = new SimpleStringProperty(id);
        this.title = new SimpleStringProperty(title);
        this.value = new SimpleStringProperty(value);
        this.vunitRate = new SimpleStringProperty(vunitRate);
        this.date = new SimpleStringProperty(date);
    }

    public StringProperty idProperty() {
        return id;
    }

    public StringProperty titleProperty() {
        return title;
    }

    public StringProperty valueProperty() {
        return value;
    }

    public StringProperty vunitRateProperty() {
        return vunitRate;
    }
    public StringProperty dateProperty() {
        return date;
    }
    public String getDate() {
        return date.get();
    }

    public String getId() {
        return id.get();
    }

    public String getTitle() {
        return title.get();
    }

    public String getValue() {
        return value.get();
    }

    public String getVunitRate() {
        return vunitRate.get();
    }
}