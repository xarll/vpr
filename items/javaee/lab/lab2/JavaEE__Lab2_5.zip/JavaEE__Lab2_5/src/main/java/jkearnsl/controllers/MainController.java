package jkearnsl.controllers;

import jkearnsl.models.MainModel;
import jkearnsl.views.main.CurrencyQuote;
import jkearnsl.views.main.MainView;

import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;

public class MainController {
    private final MainModel model;
    public final MainView view;

    public MainController(MainModel model) {
        this.model = model;
        this.view = new MainView(this);

        this.model.addObserver(this.view);

        this.view.loaded();
    }

    public void loadQuotes(LocalDate from, LocalDate to) {
        model.loadQuotes(from, to);
    }

    public boolean getIsDynamicState() {
        return model.getIsDynamic();
    }

    public ArrayList<CurrencyQuote> getQuotes() {
        return model.getQuotes();
    }
}
