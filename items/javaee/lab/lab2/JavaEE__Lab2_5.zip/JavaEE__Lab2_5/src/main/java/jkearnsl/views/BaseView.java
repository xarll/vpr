package jkearnsl.views;

import javafx.scene.Scene;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import jkearnsl.controllers.MainController;
import jkearnsl.utils.DObserver;

public abstract class BaseView extends DObserver {
    protected Scene scene;
    public Scene getScene() {
        return this.scene;
    }
}
