package jkearnsl.utils;

public abstract class DObserver {
    public abstract void modelChanged();

}
