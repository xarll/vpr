package jkearnsl.views.main;

import javafx.geometry.Pos;
import javafx.scene.chart.LineChart;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;

public class UiMain {

    private final VBox root;

    DatePicker fromDate;
    DatePicker toDate;
    TableView<CurrencyQuote> tableView;
    VBox legendContainer;
    LineChart<Number, Number> lineChart;
    Button send;
    VBox respContainer;
    HBox graphContainer;


    UiMain(VBox root) {
        this.root = root;
    }

    void setup_ui() {
        root.setStyle("-fx-background-color: #c79cb3;");
        root.setSpacing(10);
        root.setAlignment(Pos.CENTER_RIGHT);

        // Date
        HBox dateLayout = new HBox();
        dateLayout.setSpacing(10);
        dateLayout.setAlignment(Pos.CENTER_RIGHT);
        root.getChildren().add(dateLayout);

        // From
        fromDate = new DatePicker();
        fromDate.setPromptText("From");
        fromDate.setPrefWidth(200);
        dateLayout.getChildren().add(fromDate);

        // To
        toDate = new DatePicker();
        toDate.setPromptText("To");
        toDate.setPrefWidth(200);
        dateLayout.getChildren().add(toDate);


        // Response Table
        tableView = new TableView<>();
        tableView.setTableMenuButtonVisible(true);
        VBox.setVgrow(tableView, Priority.ALWAYS);

        TableColumn<CurrencyQuote, String> idCol = new TableColumn<>("ID");
        idCol.setMinWidth(100);
        idCol.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");
        idCol.setCellValueFactory(cellData -> cellData.getValue().idProperty());
        idCol.setCellFactory(TextFieldTableCell.forTableColumn());

        TableColumn<CurrencyQuote, String> titleCol = new TableColumn<>("Валюта");
        titleCol.setMinWidth(150);
        titleCol.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");
        titleCol.setCellValueFactory(cellData -> cellData.getValue().titleProperty());
        titleCol.setCellFactory(TextFieldTableCell.forTableColumn());

        TableColumn<CurrencyQuote, String> valueCol = new TableColumn<>("Цена в рублях");
        valueCol.setMinWidth(200);
        valueCol.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");
        valueCol.setCellValueFactory(cellData -> cellData.getValue().valueProperty());
        valueCol.setCellFactory(TextFieldTableCell.forTableColumn());

        TableColumn<CurrencyQuote, String> vunitRateCol = new TableColumn<>("Курс за 1 eд");
        vunitRateCol.setMinWidth(200);
        vunitRateCol.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");
        vunitRateCol.setCellValueFactory(cellData -> cellData.getValue().vunitRateProperty());
        vunitRateCol.setCellFactory(TextFieldTableCell.forTableColumn());

        TableColumn<CurrencyQuote, String> dateCol = new TableColumn<>("Дата");
        dateCol.setMinWidth(150);
        dateCol.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");
        dateCol.setCellValueFactory(cellData -> cellData.getValue().dateProperty());
        dateCol.setCellFactory(TextFieldTableCell.forTableColumn());


        tableView.getColumns().addAll(idCol, titleCol, valueCol, vunitRateCol, dateCol);

        // Response lineChart
        graphContainer = new HBox();
        lineChart = new LineChart<Number, Number>(
                new javafx.scene.chart.NumberAxis(),
                new javafx.scene.chart.NumberAxis()
        );
        lineChart.setTitle("Графики");
        lineChart.setLegendVisible(false);
        VBox.setVgrow(lineChart, Priority.ALWAYS);
        graphContainer.getChildren().add(lineChart);

        // Legend
        legendContainer = new VBox();
        legendContainer.setAlignment(Pos.CENTER);
        legendContainer.setSpacing(10);
        graphContainer.getChildren().add(legendContainer);

        // Send
        send = new Button("Отобразить");
        send.setPrefWidth(100);
        root.getChildren().add(send);

        // RespContainer
        respContainer = new VBox();
        root.getChildren().add(respContainer);
    }
}


