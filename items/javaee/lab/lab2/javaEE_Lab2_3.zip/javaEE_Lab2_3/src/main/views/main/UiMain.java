package main.views.main;

import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;


public class UiMain {

    private final VBox root;

    ComboBox<String> method;
    TextField url;
    Label status;
    TextArea response;
    Button send;


    UiMain(VBox root) {
        this.root = root;
    }

    void setup_ui() {
        root.setStyle("-fx-background-color: #c79cb3;");
        root.setSpacing(10);
        root.setAlignment(Pos.CENTER_RIGHT);

        // Url
        url = new TextField();
        url.setPromptText("Enter URL");
        url.setPrefWidth(400);

        // Method
        method = new ComboBox<>();
        method.getItems().addAll("GET", "POST");
        method.setValue("GET");
        method.setPrefWidth(100);

        // Status
        status = new Label();
        status.setStyle("-fx-font-size: 20px; -fx-text-fill: #ccffda; -fx-font-weight: bold;");
        status.setPrefWidth(100);

        // row
        HBox queryRow = new HBox();
        queryRow.setSpacing(10);
        queryRow.setAlignment(Pos.CENTER);
        queryRow.getChildren().addAll(method, url, status);
        root.getChildren().add(queryRow);

        // Response
        response = new TextArea();
        response.setPrefWidth(500);
        response.setPrefHeight(300);
        response.setEditable(false);
        root.getChildren().add(response);

        // Send
        send = new Button("Send");
        send.setPrefWidth(100);
        root.getChildren().add(send);
    }
}


