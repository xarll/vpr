package main.utils;

public abstract class DObserver {
    public abstract void modelChanged();

}
