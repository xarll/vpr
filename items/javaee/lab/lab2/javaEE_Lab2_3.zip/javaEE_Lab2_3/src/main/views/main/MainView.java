package main.views.main;

import javafx.event.ActionEvent;
import javafx.scene.Scene;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import main.controllers.MainController;
import main.views.BaseView;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;


public class MainView extends BaseView {
    private final UiMain ui;
    private final MainController controller;


    public MainView(MainController controller) {
        var root = new VBox();
        scene = new Scene(root, 600, 400);

        this.controller = controller;

        this.ui = new UiMain(root);
        this.ui.setup_ui();

        // Регистрация событий
        ui.send.setOnAction(this::sendClicked);
    }

    private void sendClicked(ActionEvent actionEvent) {
        String urlStr = ui.url.getText();
        String method = ui.method.getValue();

        if (urlStr.isEmpty()) {
            ui.url.requestFocus();
            return;
        }

        URL url;
        try {
            url = new URL(urlStr);
        } catch (MalformedURLException errorObj) {
            ui.response.setText(errorObj.getMessage());
            return;
        }

        controller.makeRequest(url, method);
    }

    public void modelChanged() {
        ui.response.setText(controller.getResponse());
        ui.status.setText(controller.getStatus());
    }

    public void loaded() {
        modelChanged();
    }
}