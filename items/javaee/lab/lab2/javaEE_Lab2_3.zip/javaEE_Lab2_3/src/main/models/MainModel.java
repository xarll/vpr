package main.models;


import main.utils.DObserver;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class MainModel {

    private final ArrayList<Object> observers;

    Integer status;
    String response;
    public MainModel() {
        this.observers = new ArrayList<>();
    }


    public void makeRequest(URL url, String method) {
        try {
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setRequestProperty("User-Agent", "Mozilla/5.0");
            connection.setConnectTimeout(1000);
            connection.setRequestMethod(method);

            status = connection.getResponseCode();

            InputStream inputStream = connection.getInputStream();

            // Читаем ответ
            byte[] buffer = new byte[1024];
            int bytesRead;
            StringBuilder responseContent = new StringBuilder();
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                responseContent.append(new String(buffer, 0, bytesRead));
            }
            inputStream.close();

            response = responseContent.toString();
        } catch (IOException errorObj) {
            response = errorObj.getMessage();
        }
        notifyObservers();
    }

    public String getResponse() {
        if (response == null) {
            return "";
        }
        return response;
    }

    public String getStatus() {
        if (status == null) {
            return "";
        }
        return status.toString();
    }

    public void addObserver(DObserver observer) {
        this.observers.add(observer);
    }

    public void notifyObservers() {
        for (Object observer : this.observers) {
            ((DObserver) observer).modelChanged();
        }
    }

    public void removeObserver(DObserver observer) {
        this.observers.remove(observer);
    }
}
